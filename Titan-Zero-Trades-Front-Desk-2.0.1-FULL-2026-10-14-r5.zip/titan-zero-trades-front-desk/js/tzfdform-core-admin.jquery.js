	$.tzfdform[ 'typeList' ] = [];
	$.tzfdform[ 'categoryList' ] = [];
	$.tzfdform[ 'controls' ] = {};
	
	$.tzfdform[ 'preview' ] = function( e )
	{
		var f  = $( e.form );
		f.attr( 'target', 'formpopup' ).attr( 
			'onsubmit', 
			function( f )
			{
				var w = screen.width*0.8,
					h = screen.height*0.7,
					l = screen.width/2 - w/2,
					t = screen.height/2 - h/2,
					new_window = window.open('', 'formpopup', 'resizeable,scrollbars,width='+w+',height='+h+',left='+l+',top='+t);
					
				$( f ).removeAttr( 'onsubmit' );
				new_window.focus();
			} 
		);
		$( '<input type="hidden" name="preview" value="1" />' ).appendTo( f );
		
		f[ 0 ].submit();
		f.attr( 'target', '_self' ).find( 'input[name="preview"]').remove();
	};
	
	$.tzfdform[ 'htmlEncode' ] = function(value)
	{
		value = $('<div/>').text(value).html()
		// .html() above already encodes & < >; only the double quote is left to encode for attribute values.
		value = value.replace(/"/g, "&quot;");
		return value;
	};
	
	// For text placed inside a <textarea>: escapes only what the parser would read as markup, so the textarea shows the stored text unchanged.
	$.tzfdform[ 'textareaEncode' ] = function(value)
	{
		return String( ( value == null ) ? '' : value ).replace( /&/g, '&amp;' ).replace( /</g, '&lt;' ).replace( />/g, '&gt;' );
	};

	$.tzfdform[ 'escape_symbol' ] = function( value ) // Escape the symbols used in regulars expressions
	{
		return value.replace(/([\^\$\-\.\,\[\]\(\)\/\\\*\?\+\!\{\}])/g, "\\$1");
	};
				
	$.tzfdform[ 'parseVal' ] = function( value, thousandSeparator, decimalSymbol )
	{
		if( value == '' ) return 0;
		value += '';
		
		thousandSeparator = new RegExp( $.tzfdform.escape_symbol( ( typeof thousandSeparator == 'undefined' ) ? ',' : thousandSeparator ), 'g' );
		decimalSymbol = new RegExp( $.tzfdform.escape_symbol( ( typeof decimalSymbol == 'undefined' ) ? '.' : decimalSymbol ), 'g' );
		
		var t = value.replace( thousandSeparator, '' ).replace( decimalSymbol, '.' ).replace( /\s/g, '' ),
			p = /[+-]?((\d+(\.\d+)?)|(\.\d+))/.exec( t );
			
		return ( p ) ? p[0]*1 : '"' + value.replace(/'/g, "\\'").replace( /\$/g, '') + '"';
	};
	
    $.tzfdform[ 'showErrorMssg' ] = function( str ) // Display an error message
    {
        $( '.form-builder-error-messages' ).empty().append( $( '<div class="error-text"></div>' ).text( str ) );
    };
    
	// tzfdform plugin
	$.fn.tzfdform = function(options){
		var opt = $.extend({},
				{
	   				pub:false,
					identifier:"",
					title:""
				},
				options, true),
			typeList = 	$.tzfdform.typeList,
			categoryList = $.tzfdform.categoryList;
			
		$.tzfdform[ 'getNameByIdFromType' ] = function( id )
			{
				for ( var i = 0, h = typeList.length; i < h; i++ )
				{
					if ( typeList[i].id == id )
					{
						return  typeList[i].name;
					}	
				}		
				return "";
			};
		
		for ( var i=0, h = typeList.length; i < h; i++ )
		{
			var category_id = typeList[ i ].control_category;
			
			if( typeof categoryList[ category_id ]  == 'undefined' )
			{
				categoryList[ category_id ] = { title : '', description : '', typeList : [] };
			}
			else if( typeof categoryList[ category_id ][ 'typeList' ]  == 'undefined' )
			{
				categoryList[ category_id ][ 'typeList' ] = [];
			}
			
			categoryList[ category_id ].typeList.push( i );
		}

		for ( var i in categoryList )
		{
			$("#tzfdtabs-1").append('<div style="clear:both;"></div><div>'+categoryList[ i ].title+'</div><hr />');
			if( typeof categoryList[ i ][ 'description' ] != 'undefined' && !/^\s*$/.test( categoryList[ i ][ 'description' ] ) )
			{
				$("#tzfdtabs-1").append('<div style="clear:both;"></div><div class="category-description">'+categoryList[ i ].description+'</div>');
			}

			if( typeof categoryList[ i ][ 'typeList' ]  != 'undefined' )
			{
				for( var j = 0, k = categoryList[ i ].typeList.length; j < k; j++ )
				{
					var index = categoryList[ i ].typeList[ j ];
					$("#tzfdtabs-1").append('<div class="button '+(((j!=0 && j != 1 && j != 2 && j != 3) || i>1)?"n":"itemForm")+'  width40" id="'+typeList[ index ].id+'">'+typeList[ index ].name+'</div>');
				}
			}	
		}
		
		$("#tzfdtabs-1").append('<div class="clearer"></div>');
		$( ".button").button();
		
		// Create a items object
		var items = [],
            fieldsIndex = {},
            calculatedFields = {},
			selected = -3;
			
		$.tzfdform[ 'editItem' ] = function( id ) 
			{		    
				selected = id;
                try 
                { 
                    $('#tzfdtabs-2').html( items[id].showAllSettings() ); 
                } catch (e) {}
				items[id].editItemEvents();
			};
			
		$.tzfdform[ 'removeItem' ] = function( index ) 
			{
				if( typeof items[ index ][ 'remove' ] != 'undefined' ) items[ index ][ 'remove' ]();
				items.splice(index,1);
				for ( var i=0, h = items.length; i<h; i++ )
				{
					items[i].index = i;
				}
				selected = -2;
				$('#tabs').tabs("option", "active", 0);
				$.tzfdform.reloadItems();
			};
			
		$.tzfdform[ 'duplicateItem' ] = function( index ) 
			{
				var n = 0;
				for ( var i=0, h = items.length; i<h; i++ )
				{
				   n1 = parseInt( items[i].name.replace( /fieldname/g,"" ) );
				   if (n1>n)
					   n = n1;
				}
				
				if( $( '#field-' + items[ index ].index ).parents( '.fields' ).length )
				{
					var i = $( '#field-' + items[ index ].index ).parents( '.fields' ).attr( 'id' ).replace( 'field-', '' );
					if( typeof items[ i ][ 'duplicateItem' ] != 'undefined' ) items[ i ][ 'duplicateItem' ]( items[ index ].name, 'fieldname'+( n + 1 ) );
				}
				
				items.splice( index*1+1, 0, $.extend( true, {}, items[index], { name:"fieldname"+(n+1) } ) );
				for ( var i=index*1+1, h = items.length; i<h; i++ )
				{
					items[i].index = i;
				}
				
				$('#tabs').tabs("option", "active", 0);
				$.tzfdform.reloadItems();
			}
		
		$.tzfdform[ 'editForm' ] = function() 
			{
				$('#tzfdtabs-3').html(theForm.showAllSettings());
				selected = -1;

				$("#fTitle").keyup(function()
				{
					theForm.title = $(this).val();
					$.tzfdform.reloadItems();
				});
				
				$("#fEvalEquations").click(function()
				{
					theForm.evalequations = ($(this).is( ':checked' )) ? 1 : 0;
					$.tzfdform.reloadItems();
				});
				
				$("#fAutofocus").click(function()
				{
					theForm.autofocus = $(this).is( ':checked' );
					$.tzfdform.reloadItems();
				});
				$("#fAutocomplete").click(function()
				{
					theForm.autocomplete = ($(this).is( ':checked' )) ? 1 : 0;
					$.tzfdform.reloadItems();
				});
				
				$("#fDescription").keyup(function()
				{
					theForm.description = $(this).val();
					$.tzfdform.reloadItems();
				});
				
				$("#fLayout").change(function()
				{
					theForm.formlayout = $(this).val();
					$.tzfdform.reloadItems();
				});
				
				$("#fTemplate").change(function()
				{
					theForm.formtemplate = $(this).val();
					var template 	= $.tzfdform.showSettings.formTemplateDic[ theForm.formtemplate ],
						thumbnail	= '',
						description = '';

					if( typeof template != 'undefined' )
					{
						if( typeof template[ 'thumbnail' ] != 'undefined' )
						{
							thumbnail = '<img src="' + template[ 'thumbnail' ] + '">';
						}
						if( typeof template[ 'description' ] != 'undefined' )
						{
							description = template[ 'description' ];
						}
					}
					$( '#fTemplateThumbnail' ).html( thumbnail );
					$( '#fTemplateDescription' ).html( description );
					$.tzfdform.reloadItems();
				});
			};
		
		$.tzfdform[ 'reloadItems' ] = function() 
			{
                
				for ( var i=0, h = $.tzfdform.showSettings.formlayoutList.length; i < h; i++ )
				{
					$("#fieldlist"+opt.identifier).removeClass( $.tzfdform.showSettings.formlayoutList[i].id );
				}	
				$("#fieldlist"+opt.identifier).addClass(theForm.formlayout);
				$("#formheader"+opt.identifier).html(theForm.display());
				$("#fieldlist"+opt.identifier).html("");
				if ( parseInt( selected ) == -1 )
				{
					$(".fform").addClass("ui-selected");
				}
				else
				{
					$(".fform").removeClass("ui-selected");
				}
				
                fieldsIndex = {};
                calculatedFields = {};
				for ( var i=0, h = items.length; i < h; i++ )
				{
					items[i].index = i;
                    fieldsIndex[ items[i].name ] = i;
                    if( items[i].ftype == 'fCalculated')
                    {
                        calculatedFields[ items[i].name ] = i;
                    }
					$("#fieldlist"+opt.identifier).append(items[i].display());
					if ( i == selected )
					{
						$("#field"+opt.identifier+"-"+i).addClass("ui-selected");
                        if( $('#tabs').tabs("option", "active") != 1 )
                        {
                            $.tzfdform[ 'editItem' ]( i );
                        }    
					}	
					else
					{
						$("#field"+opt.identifier+"-"+i).removeClass("ui-selected");
					}	
					$("#field"+opt.identifier+"-"+i+" .remove").click(function()
						{
							$.tzfdform[ 'removeItem' ]($(this).parent().attr("id").replace("field"+opt.identifier+"-",""));
						});
						
					$("#field"+opt.identifier+"-"+i+" .copy").click(function()
						{
							$.tzfdform[ 'duplicateItem' ]($(this).parent().attr("id").replace("field"+opt.identifier+"-",""));
						});
						
				}
				for ( var i=0, h = items.length; i < h; i++ )
				{
					if( typeof items[ i ].after_show != 'undefined' ) items[ i ].after_show();
				}
				if (items.length>0)
				{
				    $(".fields").mouseover(function( evt ) 
						{
							$(this).addClass("ui-over");
							evt.stopPropagation();
						})
						.mouseout(function( evt )
						{
							$(this).removeClass("ui-over");
							evt.stopPropagation();
						})
						.click(function( evt )
						{
							evt.stopPropagation();
                            $.tzfdform[ 'editItem' ]($(this).attr("id").replace("field"+opt.identifier+"-",""));
							$( '#fieldlist .ui-selected' ).removeClass("ui-selected");
							$(this).addClass("ui-selected");
							$('#tabs').tabs("option", "active", 1);
                        });
					$(".field").focus(function()
						{
							$(this).blur();
						});	
				}
				
				$(".fform").mouseover(function() 
					{
						$(this).addClass("ui-over");
					})
					.mouseout(function()
					{
						$(this).removeClass("ui-over");
					})
					.click(function( evt ){
                        evt.stopPropagation();
						$('#tabs').tabs("option", "active", 2);
						$.tzfdform.editForm();
						$(this).siblings().removeClass("ui-selected");
						$(this).addClass("ui-selected");
					});
					
				ffunct.saveData("form_structure");
				
				//email list
				var str = "",
					cu_user_email_field = $('#cu_user_email_field').attr("def").split( ',' );
					
				for ( var i=0, h = items.length; i < h; i++ )
				{
					var item = items[ i ];
					if (item.ftype=="femail" || item.ftype=="femailds")
					{
						str += '<option value="'+item.name+'" '+( ( $.inArray( item.name, cu_user_email_field ) != -1 ) ? "selected" : "" )+'>'+item.name+' ('+$.tzfdform.htmlEncode(item.title)+')'+'</option>';
					}
				}
				$('#cu_user_email_field').html(str);
				
				// recurrent payments
				var str = "",
					paypal_recurrent_field = $('[name="paypal_recurrent_field"]').attr("def");
					
				for ( var i=0, h = items.length; i < h; i++ )
				{
					var item = items[ i ];
					if (item.ftype=="fradio" || item.ftype=="fdropdown")
					{
						str += '<option value="'+item.name+'" '+( ( item.name == paypal_recurrent_field ) ? "selected" : "" )+'>'+item.name+' ('+$.tzfdform.htmlEncode(item.title)+')'+'</option>';
					}
				}
				$('[name="paypal_recurrent_field"]').html(str);
				
				//destination items list
				if (($('#fp_destination_emails_field').length > 0) && ($('#fp_destination_emails_field').is('select')))
				{
					var str = "";
					for (var i=0, h = items.length; i<h; i++)
					{
						var item = items[ i ];
						str += '<option value="'+item.name+'" '+((item.name == $('#fp_destination_emails_field').attr("def"))?"selected":"")+'>'+item.name+'('+$.tzfdform.htmlEncode(item.title)+')</option>';
					}	
					$('#fp_destination_emails_field').html(str);
				}					
				
				//field list for paypal request
				if (($('#request_cost').length > 0) && ($('#request_cost').is('select')))
				{
					var str = "",
						request_cost = $('#request_cost').attr("def");
						
					for (var i=0, h = items.length; i<h; i++)
					{
						var item = items[ i ];
						str += '<option value="'+item.name+'" '+( ( item.name == request_cost ) ? "selected" : "" )+'>'+item.name+'('+$.tzfdform.htmlEncode(item.title)+')</option>';
					}	
					$('#request_cost').html(str);
				}
				
				//request amount list
				if ($('#paypal_price_field').length > 0)
				{
					var paypal_price_field = $('#paypal_price_field').attr("def"),
						str = '<option value="" '+( ('' == paypal_price_field ) ? "selected" : "" )+'> ---- No ---- </option>';
						
					for (var i=0, h = items.length; i < h; i++)
					{
						var item = items[ i ];
						str += '<option value="'+item.name+'" '+( ( item.name == paypal_price_field ) ? "selected" : "" )+'>'+$.tzfdform.htmlEncode(item.title)+'</option>';
					}		
					$('#paypal_price_field').html(str);
				}
			};
		
		var fform=function(){};
		$.extend(fform.prototype,
			{
				title:"Untitled Form",
				description:"This is my form. Please fill it out. It's awesome!",
				formlayout:"top_aligned",
				formtemplate:"",
                evalequations:1,
                autocomplete:1,
                autofocus:false,
				display:function()
				{
					return '<div class="fform" id="field"><div class="arrow ui-icon ui-icon-play "></div><h1>'+$.tzfdform.htmlEncode(this.title)+'</h1><span>'+$.tzfdform.htmlEncode(this.description)+'</span></div>';
				},
				
				showAllSettings:function()
				{
					var layout 	    = '',
						template    = '<option value="">Use default template</option>',
						thumbnail   = '',
						description = '',
						selected    = '';
						
					for ( var i = 0; i< $.tzfdform.showSettings.formlayoutList.length; i++ )
					{
						layout += '<option value="'+$.tzfdform.showSettings.formlayoutList[i].id+'" '+(($.tzfdform.showSettings.formlayoutList[i].id==this.formlayout)?"selected":"")+'>'+$.tzfdform.showSettings.formlayoutList[i].name+'</option>';
					}	

					for ( var i in $.tzfdform.showSettings.formTemplateDic )
					{
						if( /^\s*$/.test( i ) ) break;
						selected = '';
						if( $.tzfdform.showSettings.formTemplateDic[i].prefix==this.formtemplate )
						{
							selected = 'SELECTED';
							if( typeof $.tzfdform.showSettings.formTemplateDic[i].thumbnail != 'undefined' )
							{
								thumbnail = '<img src="'+$.tzfdform.showSettings.formTemplateDic[i].thumbnail+'">'; 
							}
							
							if( typeof $.tzfdform.showSettings.formTemplateDic[i].description != 'undefined' )
							{
								description = $.tzfdform.showSettings.formTemplateDic[i].description; 
							}
						}
						
						template += '<option value="'+$.tzfdform.showSettings.formTemplateDic[i].prefix+'" ' + selected + '>'+$.tzfdform.htmlEncode($.tzfdform.showSettings.formTemplateDic[i].title)+'</option>';
					}	
					return '<div><label>Form Name</label><input class="large" name="fTitle" id="fTitle" value="'+$.tzfdform.htmlEncode(this.title)+'" /></div><div><label>Description</label><textarea class="large" name="fDescription" id="fDescription">'+$.tzfdform.textareaEncode(this.description)+'</textarea></div><div><label>Label Placement</label><br /><select name="fLayout" id="fLayout" class="large">'+layout+'</select></div><div><label><input type="checkbox" name="fAutofocus" id="fAutofocus" '+( ( this.autofocus ) ? 'CHECKED' : '' )+' /> Auto-focus booking form when the page is loaded</label></div><div><label><input type="checkbox" name="fAutocomplete" id="fAutocomplete" '+( ( this.autocomplete ) ? 'CHECKED' : '' )+' /> Enable autocompletion</label></div>' + ( ( typeof $.tzfdform.controls[ 'fCalculated' ] != 'undefined' ) ? '<div><label><input type="checkbox" name="fEvalEquations" id="fEvalEquations" '+( ( this.evalequations ) ? 'CHECKED' : '' )+' /> Eval dynamically the equations associated to the calculated fields</label></div>' : '' ) + '<div><label>Form Template</label><br /><select name="fTemplate" id="fTemplate" class="large">'+template+'</select></div><br /><div><span id="fTemplateThumbnail" style="float:left;padding-right:10px;">'+thumbnail+'</span><span  id="fTemplateDescription" style="float:left;">'+description+'</span></div>' ;
				}
			}
		);
		
		var theForm = new fform();
		$("#tzfdform").click( function( evt )
            { 
                evt.stopPropagation();
                selected = -2;
                $(".fform").removeClass("ui-selected")
                $( '#fieldlist .ui-selected' ).removeClass("ui-selected");
                $('#tabs').tabs("option", "active", 0);
            } 
        );
        $("#fieldlist"+opt.identifier).sortable(
			{
				'connectWith': '.ui-sortable',
				'items': '.fields',
				'update': function( event, ui )
				{
					var i, h = items.length;
					for( i = 0; i < h; i++ )
					{
						if( ui.item.hasClass( items[ i ].name ) ) break;
					}
						
					if( ui.item.parent().attr( 'id' ) == 'fieldlist' )
					{
						// receive or change order in fieldlist
						var end_pos = parseInt( ui.item.index() );
						items.splice( end_pos, 0,  items.splice( i, 1 )[ 0 ] );
						$.tzfdform.reloadItems();
					}
					else
					{
						// remove
						items = items.concat( items.splice( i, 1 ) );
					}
				}
			}   
		);
		
		$('#tabs').tabs(
			{
				activate: function(event, ui) 
					{
						switch( $(this).tabs( "option", "active" ) )
						{
							case 0:
								$(".fform").removeClass("ui-selected");
							break;
							case 1:
								$(".fform").removeClass("ui-selected");
								if (selected < 0)
								{
								   $('#tzfdtabs-2').html('<b>No Field Selected</b><br />Please click on a field in the form preview on the right to change its properties.');
								}
							break;
							case 2:
								$(".fields").removeClass("ui-selected");
								$(".fform").addClass("ui-selected");
								$.tzfdform.editForm();
							break;
						}
					}	   
			}		
		);
		
	    var ffunct = {
	        getFieldsIndex: function() 
			{
			   return fieldsIndex;
		    },
		    getCalculatedFields: function() 
			{
			   return calculatedFields;
		    },
		    getItems: function() 
			{
			   return items;
		    },
		    addItem: function(id) 
			{
			    var obj = new $.tzfdform.controls[id](),
					fBuild = this,
					n = 0;

				obj.init();
			    for (var i=0, h = items.length; i < h; i++)
			    {
		 		    n1 = parseInt(items[i].name.replace(/fieldname/g,""));
	 			    if (n1>n)
					{
					   n = n1;
					}   
 			    }
				n++;
				obj.fBuild = fBuild;
			    $.extend(obj,{name:"fieldname"+n});
                
                if( selected >= 0 )
                {
                    items.splice( (selected)*1+1, 0, obj );
                    if( typeof items[ selected ][ 'addItem' ] != 'undefined' )
                    {
                        items[ selected ][ 'addItem' ]( obj.name );
                    }
                    else
                    {
                        selected++;
                    }
                }
                else
                {
                    selected = items.length;
                    items[selected] = obj;
                }    
				$.tzfdform.reloadItems();
				return obj;
		    },
		    saveData:function(f)
			{
                var itemsStringified   = $.stringifyXX( items ),
                    theFormStringified = $.stringifyXX( theForm ),
                    errorTxt = 'The entered data includes invalid characters. Please, if you are copying and pasting from another platform, be sure the data not include invalid characters.',
                    str;
                
                if( typeof global_varible_save_data != 'undefined' )
                {
                    // If the global_varible_save_data exists clear the form-builder-error-messages
                    $( '.form-builder-error-messages' ).html( '' );
                }
                
                try{
                    if( $.parseJSON( itemsStringified ) != null && $.parseJSON( theFormStringified ) != null )
                    {
                        str = "["+ itemsStringified +",["+ theFormStringified +"]]";
                        $( "#"+f ).val( str );
                        $( "#form_structure_crc" ).val( str.length );
                    }
                    else
                    {
                        $.tzfdform[ 'showErrorMssg' ]( errorTxt );
                    }    
                }
                catch( err )
                {
                    $.tzfdform[ 'showErrorMssg' ]( errorTxt );
                }
                
                global_varible_save_data = true;
		    },
		    loadData:function(form_structure, available_templates)
			{
		        var structure = $.parseJSON( $("#"+form_structure).val() ), // JSON data
					templates = ( typeof available_templates == 'undefined' ) ? null : $.parseJSON( $("#"+available_templates).val() ),
					fBuild = this;

			    if ( structure )
				{
					if (structure.length==2)
					{
						items = [];
						for (var i=0;i<structure[0].length;i++)
						{
						   var obj = new $.tzfdform.controls[structure[0][i].ftype]();
						   obj = $.extend( true, {}, obj, structure[0][i] );
						   obj.name = obj.name+opt.identifier;
						   obj.form_identifier = opt.identifier;
						   obj.fBuild = fBuild;
						   items[items.length] = obj;
						}
						theForm = new fform();
						theForm = $.extend(theForm,structure[1][0]);
						$.tzfdform.reloadItems();
					}
				}
				
				if( templates )
				{
					$.tzfdform.showSettings.formTemplateDic = templates;
				}
		    },
		    removeItem: $.tzfdform[ 'removeItem' ],
		    editItem:   $.tzfdform[ 'editItem' ]
	    }
	   
	    this.fBuild = ffunct;
	    return this;
	};

    $.tzfdform[ 'showSettings' ] = {
		sizeList:new Array({id:"small",name:"Small"},{id:"medium",name:"Medium"},{id:"large",name:"Large"}),
		layoutList:new Array({id:"one_column",name:"One Column"},{id:"two_column",name:"Two Column"},{id:"three_column",name:"Three Column"},{id:"side_by_side",name:"Side by Side"}),
		formlayoutList:new Array({id:"top_aligned",name:"Top Aligned"},{id:"left_aligned",name:"Left Aligned"},{id:"right_aligned",name:"Right Aligned"},{id:"center_aligned",name:"Center Aligned"}),
		formTemplateDic: {}, // Form Template dictionary
        showFieldType: function( v )
        {
            return '<label>Field Type: '+$.tzfdform[ 'getNameByIdFromType' ]( v )+'</label><br /><br />';
        },
		showTitle: function(v) 
		{
			return '<label>Field Label</label><textarea class="large" name="sTitle" id="sTitle">'+$.tzfdform.htmlEncode(v)+'</textarea>';
		},
		showShortLabel: function( v )
		{
			return '<div><label>Short label (optional) [<a class="helptzfdform" text="The short label is used at title for the column when exporting the form data to CSV files.\n\nIf the short label is empty then, the field label will be used for the CSV file.">help?</a>] :</label><input class="large" name="sShortlabel" id="sShortlabel" value="'+$.tzfdform.htmlEncode(v)+'" /></div>';
		},
		showName: function( v ) 
		{
			return '<div><label>Field name, tag for the message:</label><input readonly="readonly" class="large" name="sNametag" id="sNametag" value="&lt;%'+v+'%&gt;" />'+
				   '<input style="display:none" readonly="readonly" class="large" name="sName" id="sName" value="'+v+'" /></div>';
		},
		showPredefined: function(v,c) 
		{
			return '<div><label>Predefined Value</label><textarea class="large" name="sPredefined" id="sPredefined">'+v+'</textarea><br /><input type="checkbox" name="sPredefinedClick" id="sPredefinedClick" '+((c)?"checked":"")+' value="1" > Use predefined value as placeholder.</div>';
		},
		showEqualTo: function(v,name) 
		{
			return '<div><label>Equal to [<a class="helptzfdform" text="Use this field to create password confirmation field or email confirmation fields.\n\nSpecify this setting ONLY into the confirmation field, not in the original field.">help?</a>]</label><br /><select class="equalTo" name="sEqualTo" id="sEqualTo" dvalue="'+v+'" dname="'+name+'"></select></div>';
		},
		showRequired: function(v) 
		{
			return '<div><input type="checkbox" name="sRequired" id="sRequired" '+((v)?"checked":"")+'><label>Required</label></div>';
		},
		showSize: function(v) 
		{
			var str = "";
			for (var i=0;i<this.sizeList.length;i++)
			{
				str += '<option value="'+this.sizeList[i].id+'" '+((this.sizeList[i].id==v)?"selected":"")+'>'+this.sizeList[i].name+'</option>';
			}	
			return '<label>Field Size</label><br /><select name="sSize" id="sSize">'+str+'</select>';
		},
		showLayout: function(v) 
		{
			var str = "";
			for (var i=0;i<this.layoutList.length;i++)
			{
				str += '<option value="'+this.layoutList[i].id+'" '+((this.layoutList[i].id==v)?"selected":"")+'>'+this.layoutList[i].name+'</option>';
			}	
			return '<label>Field Layout</label><br /><select name="sLayout" id="sLayout">'+str+'</select>';
		},
		showUserhelp: function(v,c) 
		{
			return '<div><label>Instructions for User</label><textarea class="large" name="sUserhelp" id="sUserhelp">'+v+'</textarea><br /><input type="checkbox" name="sUserhelpTooltip" id="sUserhelpTooltip" '+((c)?"checked":"")+' value="1" > Show as floating tooltip.</div>';
		},
		showCsslayout: function(v) 
		{
			return '<label>Additional CSS Class</label><input class="large" name="sCsslayout" id="sCsslayout" value="'+$.tzfdform.htmlEncode(v)+'" />';
		}
	};
	
	$.tzfdform.controls[ 'ffields' ] = function(){};
	$.extend( $.tzfdform.controls[ 'ffields' ].prototype, 
		{
			form_identifier:"",
			name:"",
			shortlabel:"",
			index:-1,
			ftype:"",
			userhelp:"",
			userhelpTooltip:false,
			csslayout:"",
			init:function(){},
			editItemEvents:function( e )
			{
				if( typeof e != 'undefined' && typeof e.length != 'undefined' )
				{
					for( var i = 0, h = e.length; i<h; i++ )
					{
						/**
						* s -> selector
						* e -> event name
						* l -> element
						* f -> function to apply the value
						*/
						$(e[i].s).bind(e[i].e, {obj:this, i:e[i]}, function(e){
							var v = $(this).val();
							if(typeof e.data.i['f'] != 'undefined') v = e.data.i.f($(this));
							e.data.obj[e.data.i.l] = v;
							$.tzfdform.reloadItems( {'field': e.data.obj} );
						});
					}
				}
				if( typeof e != 'undefined' && typeof e.length != 'undefined' )
				{
					for( var i = 0, h = e.length; i<h; i++ )
					{
						/**
						* s -> selector
						* e -> event name
						* l -> element
						* f -> function to apply the value
						*/
						$(e[i].s).bind(e[i].e, {obj:this, i:e[i]}, function(e){
							var v = $(this).val();
							if(typeof e.data.i['f'] != 'undefined') v = e.data.i.f($(this));
							e.data.obj[e.data.i.l] = v;
							$.tzfdform.reloadItems( {'field': e.data.obj} );
						});
					}	
				}
				$("#sTitle").bind("keyup", {obj: this}, function(e) 
					{
						var str = $(this).val();
						e.data.obj.title = str.replace(/\n/g,"<br />");
						$.tzfdform.reloadItems();
					});
					
				$("#sShortlabel").bind("keyup", {obj: this}, function(e) 
					{
						e.data.obj.shortlabel = $(this).val();
						$.tzfdform.reloadItems();
					});
					
				$("#sPredefined").bind("keyup", {obj: this}, function(e) 
					{
						e.data.obj.predefined = $(this).val();
						$.tzfdform.reloadItems();
					});
					
				$("#sPredefinedClick").bind("click", {obj: this}, function(e) 
					{
						e.data.obj.predefinedClick = $(this).is(':checked');
						$.tzfdform.reloadItems();
					});
					
				$("#sRequired").bind("click", {obj: this}, function(e) 
					{
						e.data.obj.required = $(this).is(':checked');
						$.tzfdform.reloadItems();
					});
					
				$("#sUserhelp").bind("keyup", {obj: this}, function(e) 
					{
						e.data.obj.userhelp = $(this).val();
						$.tzfdform.reloadItems();
					});
					
				$("#sUserhelpTooltip").bind("click", {obj: this}, function(e) 
					{
						e.data.obj.userhelpTooltip = $(this).is(':checked');
						$.tzfdform.reloadItems();
					});
					
				$("#sCsslayout").bind("keyup", {obj: this}, function(e) 
					{
						e.data.obj.csslayout = $(this).val();
						$.tzfdform.reloadItems();
					});
					
				$(".helptzfdform").click(function()
					{
						alert($(this).attr("text"));
					});
			},
			
			showSpecialData:function()
			{
				if(typeof this.showSpecialDataInstance != 'undefined')
				{
					return this.showSpecialDataInstance();
				}	
				else
				{
					return "";
				}	
			},
			
			showEqualTo:function()
			{
				if(typeof this.equalTo != 'undefined')
				{
					return $.tzfdform.showSettings.showEqualTo(this.equalTo,this.name);
				}	
				else
				{
					return "";
				}	
			},
			
			showPredefined:function()
			{
				if(typeof this.predefined != 'undefined')
				{
					return $.tzfdform.showSettings.showPredefined(this.predefined,this.predefinedClick);
				}	
				else
				{
					return "";
				}	
			},
			
			showRequired:function()
			{
				if(typeof this.required != 'undefined')
				{
					return $.tzfdform.showSettings.showRequired(this.required);
				}	
				else
				{
					return "";
				}	
			},
			
			showSize:function()
			{
				if(typeof this.size != 'undefined')
				{
					return $.tzfdform.showSettings.showSize(this.size);
				}	
				else
				{
					return "";
				}	
			},
			
			showLayout:function()
			{
				if(typeof this.layout != 'undefined')
				{
					return $.tzfdform.showSettings.showLayout(this.layout);
				}	
				else
				{
					return "";
				}	
			},
			
			showRange:function()
			{
				if(typeof this.min != 'undefined')
				{
					return this.showRangeIntance();
				}	
				else
				{
					return "";
				}	
			},
			
			showFormat:function()
			{
				if(typeof this.dformat != 'undefined')
				{
					try 
					{
						return this.showFormatIntance();
					} catch(e) {return "";}
				}	
				else
				{
					return "";
				}	
			},
			
			showChoice:function()
			{
				if(typeof this.choices != 'undefined')
				{
					return this.showChoiceIntance();
				}	
				else
				{
					return "";
				}	
			},
			
			showUserhelp:function()
			{
				return $.tzfdform.showSettings.showUserhelp(this.userhelp,this.userhelpTooltip);
			},
			
			showCsslayout:function()
			{
				return $.tzfdform.showSettings.showCsslayout(this.csslayout);
			},
			
			showAllSettings:function()
			{
				return this.showFieldType()+this.showTitle()+this.showShortLabel()+this.showName()+this.showSize()+this.showLayout()+this.showFormat()+this.showRange()+this.showRequired()+this.showSpecialData()+this.showEqualTo()+this.showPredefined()+this.showChoice()+this.showUserhelp()+this.showCsslayout();
			},
			
			showFieldType:function()
			{
				return $.tzfdform.showSettings.showFieldType(this.ftype);
			},
			
			showTitle:function()
			{
				return $.tzfdform.showSettings.showTitle(this.title);
			},
			
			showName:function()
			{
				return $.tzfdform.showSettings.showName(this.name);
			},
			
			showShortLabel:function()
			{
				return $.tzfdform.showSettings.showShortLabel(this.shortlabel);
			},
			
			display:function()
			{
				return 'Not available yet';
			},
			
			show:function()
			{
				return 'Not available yet';
			}
		}
	);
(function($) {
    var __WDAY = new Array(i18n.dcmvcal.dateformat.sun, i18n.dcmvcal.dateformat.mon, i18n.dcmvcal.dateformat.tue, i18n.dcmvcal.dateformat.wed, i18n.dcmvcal.dateformat.thu, i18n.dcmvcal.dateformat.fri, i18n.dcmvcal.dateformat.sat),
        __WDAYLarge = new Array(i18n.dcmvcal.dateformat.sunday, i18n.dcmvcal.dateformat.monday, i18n.dcmvcal.dateformat.tuesday, i18n.dcmvcal.dateformat.wednesday, i18n.dcmvcal.dateformat.thursday, i18n.dcmvcal.dateformat.friday, i18n.dcmvcal.dateformat.saturday),
        __WDAY2 = new Array(i18n.dcmvcal.dateformat.sun2, i18n.dcmvcal.dateformat.mon2, i18n.dcmvcal.dateformat.tue2, i18n.dcmvcal.dateformat.wed2, i18n.dcmvcal.dateformat.thu2, i18n.dcmvcal.dateformat.fri2, i18n.dcmvcal.dateformat.sat2),
        __MonthName = new Array(i18n.dcmvcal.dateformat.jan, i18n.dcmvcal.dateformat.feb, i18n.dcmvcal.dateformat.mar, i18n.dcmvcal.dateformat.apr, i18n.dcmvcal.dateformat.may, i18n.dcmvcal.dateformat.jun, i18n.dcmvcal.dateformat.jul, i18n.dcmvcal.dateformat.aug, i18n.dcmvcal.dateformat.sep, i18n.dcmvcal.dateformat.oct, i18n.dcmvcal.dateformat.nov, i18n.dcmvcal.dateformat.dec),
        __MonthNameLarge = new Array(i18n.dcmvcal.dateformat.l_jan, i18n.dcmvcal.dateformat.l_feb, i18n.dcmvcal.dateformat.l_mar, i18n.dcmvcal.dateformat.l_apr, i18n.dcmvcal.dateformat.l_may, i18n.dcmvcal.dateformat.l_jun, i18n.dcmvcal.dateformat.l_jul, i18n.dcmvcal.dateformat.l_aug, i18n.dcmvcal.dateformat.l_sep, i18n.dcmvcal.dateformat.l_oct, i18n.dcmvcal.dateformat.l_nov, i18n.dcmvcal.dateformat.l_dec),
        __MilitaryTime = !0,
        __TheContainer = "",
        arrs = new Array;
    arrs[i18n.dcmvcal.dateformat.year_index] = "yyyy", arrs[i18n.dcmvcal.dateformat.month_index] = "M", arrs[i18n.dcmvcal.dateformat.day_index] = "d", i18n.dcmvcal.dateformat.fulldayvalue = arrs.join(i18n.dcmvcal.dateformat.separator);
    var dialogUnBlur = function() {
        function t() {
            $(".ui-button").blur()
        }
        t(), $("body").click(t), $(".ui-button").off("focus")
    };
    if (!Clone || "function" != typeof Clone) var Clone = function(t) {
        var e = new Object;
        for (var a in e = t.constructor == Object ? new t.constructor : new t.constructor(t.valueOf()), t) e[a] != t[a] && ("object" == typeof t[a] ? e[a] = Clone(t[a]) : e[a] = t[a]);
        return e.toString = t.toString, e.valueOf = t.valueOf, e
    };
    if (!dateFormat || "function" != typeof dateFormat) var dateFormat = function(t) {
        var e = {
            "M+": this.getMonth() + 1,
            "d+": this.getDate(),
            "h+": this.getHours(),
            "H+": this.getHours(),
            "m+": this.getMinutes(),
            "s+": this.getSeconds(),
            "q+": Math.floor((this.getMonth() + 3) / 3),
            w: "0123456".indexOf(this.getDay()),
            W: __WDAY[this.getDay()],
            L: __MonthName[this.getMonth()]
        };
        /(y+)/.test(t) && (t = t.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length)));
        var a = t;
        for (var o in e) new RegExp("(" + o + ")").test(t) && new RegExp("(" + o + ")").test(a) && (t = t.replace(RegExp.$1, 1 == RegExp.$1.length ? e[o] : ("00" + e[o]).substr(("" + e[o]).length)));
        return t
    };
    if (!DateAdd || "function" != typeof DateDiff) var DateAdd = function(interval, number, idate) {
        var date;
        switch (number = parseInt(number), "string" == typeof idate && (date = idate.split(/\D/), date = new (Function.prototype.bind.apply(Date, [null].concat(date.map(Number))))()), "object" == typeof idate && (date = new Date(idate.toString())), interval) {
            case "y":
                date.setFullYear(date.getFullYear() + number);
                break;
            case "m":
                date.setMonth(date.getMonth() + number);
                break;
            case "d":
                date.setDate(date.getDate() + number);
                break;
            case "w":
                date.setDate(date.getDate() + 7 * number);
                break;
            case "h":
                date.setHours(date.getHours() + number);
                break;
            case "n":
                date.setMinutes(date.getMinutes() + number);
                break;
            case "s":
                date.setSeconds(date.getSeconds() + number);
                break;
            case "l":
                date.setMilliseconds(date.getMilliseconds() + number)
        }
        return date
    };
    if (!DateDiff || "function" != typeof DateDiff) var DateDiff = function(t, e, a) {
        switch (t) {
            case "d":
            case "w":
                e = new Date(e.getFullYear(), e.getMonth(), e.getDate()), a = new Date(a.getFullYear(), a.getMonth(), a.getDate());
                break;
            case "h":
                e = new Date(e.getFullYear(), e.getMonth(), e.getDate(), e.getHours()), a = new Date(a.getFullYear(), a.getMonth(), a.getDate(), a.getHours());
                break;
            case "n":
                e = new Date(e.getFullYear(), e.getMonth(), e.getDate(), e.getHours(), e.getMinutes()), a = new Date(a.getFullYear(), a.getMonth(), a.getDate(), a.getHours(), a.getMinutes());
                break;
            case "s":
                e = new Date(e.getFullYear(), e.getMonth(), e.getDate(), e.getHours(), e.getMinutes(), e.getSeconds()), a = new Date(a.getFullYear(), a.getMonth(), a.getDate(), a.getHours(), a.getMinutes(), a.getSeconds())
        }
        var o = e.getTime(),
            n = a.getTime(),
            i = NaN;
        switch (t) {
            case "y":
                i = a.getFullYear() - e.getFullYear();
                break;
            case "m":
                i = 12 * (a.getFullYear() - e.getFullYear()) + a.getMonth() - e.getMonth();
                break;
            case "d":
                i = Math.floor(n / 864e5) - Math.floor(o / 864e5);
                break;
            case "w":
                i = Math.floor((n + 3456e5) / 6048e5) - Math.floor((o + 3456e5) / 6048e5);
                break;
            case "h":
                i = Math.floor(n / 36e5) - Math.floor(o / 36e5);
                break;
            case "n":
                i = Math.floor(n / 6e4) - Math.floor(o / 6e4);
                break;
            case "s":
                i = Math.floor(n / 1e3) - Math.floor(o / 1e3);
                break;
            case "l":
                i = n - o
        }
        return i
    };
    null == $.fn.noSelect && ($.fn.noSelect = function(t) {
        return prevent = null == t || t, prevent ? this.each((function() {
            $.tzfdbrowser.msie || $.tzfdbrowser.safari ? $(this).bind("selectstart", (function(t) {
                return !1
            })) : $.tzfdbrowser.mozilla ? ($(this).css("MozUserSelect", "none"), $("body").trigger("focus")) : $.tzfdbrowser.opera ? $(this).bind("mousedown", (function(t) {
                t.stopPropagation()
            })) : $(this).attr("unselectable", "on")
        })) : this.each((function() {
            $.tzfdbrowser.msie || $.tzfdbrowser.safari ? $(this).unbind("selectstart") : $.tzfdbrowser.mozilla ? $(this).css("MozUserSelect", "inherit") : $.tzfdbrowser.opera ? $(this).unbind("mousedown") : $(this).removeAttr("unselectable", "on")
        }))
    }), $.fn.bcalendar = function(option) {
        var def = {
                newWidthGroup: 0,
                newWidthGroupCalculate: !1,
                list_eventsPerPage: 0,
                currentlist: {
                    dend: "",
                    idend: 0
                },
                cachepages: new Array,
                lastdate: "",
                page: 0,
                numberOfMonths: 12,
                view: "nMonth",
                weekstartday: 0,
                showtooltip: !1,
                tooltipon: 1,
                shownavigate: !1,
                navigateurl: "",
                target: 0,
                theme: "#" + option.paletteDefault,
                height: !1,
                url: "",
                eventItems: [],
                method: "POST",
                showday: new Date,
                onBeforeRequestData: !1,
                onAfterRequestData: !1,
                onRequestDataError: !1,
                onWeekOrMonthToDay: !1,
                quickAddHandler: !1,
                quickAddUrl: "",
                quickUpdateUrl: "",
                quickDeleteUrl: "",
                autoload: !1,
                readonly: !1,
                extParam: [],
                enableDrag: !0,
                loadDateR: []
            },
            eventDiv = $("#gridEvent" + option.thecontainer);
        0 == eventDiv.length && (eventDiv = $("<div id='gridEvent" + option.thecontainer + "' style='display:none;'></div>").appendTo(document.body));
        var gridcontainer = $(this);
        option = $.extend(def, option), __MilitaryTime = option.militaryTime, null != option.quickUpdateUrl && "" != option.quickUpdateUrl || (option.enableDrag = !1), "dc_subjects" != option.rowsByCategory && "dc_locations" != option.rowsByCategory || (option.rowsList = window[option.rowsByCategory]), option.dayWithTime && "day" == option.view && (option.rowsList = ""), "dc_subjects" != option.dayWithColumns && "dc_locations" != option.dayWithColumns || (option.columnsList = window[option.dayWithColumns]);
        var __SCOLLEVENTTEMP = '<DIV style="WIDTH:${width};top:${top};left:${left};" title1="${title}" class="chip chip${i} ${drag}"><div class="dhdV" style="display:none">${data}</div><DIV style="BORDER-BOTTOM-COLOR:${bdcolor}" class=ct>&nbsp;</DIV><DL class="${userEdition}" style="BORDER-BOTTOM-COLOR:${bdcolor}; BACKGROUND-COLOR:${bgcolor1}; BORDER-TOP-COLOR: ${bdcolor}; HEIGHT: ${height}px; BORDER-RIGHT-COLOR:${bdcolor}; BORDER-LEFT-COLOR:${bdcolor}"><DT style="BACKGROUND-COLOR:${bgcolor2}">${starttime} ${icon}</DT><DD><SPAN class="t-title">${content}</SPAN><div class="t-loc">${location}</div><div class="t-desc">${description}</div></DD><DIV class=\'resizer\' style=\'display:${redisplay}\'><DIV class=rszr_icon>&nbsp;</DIV></DIV></DL><DIV style="BORDER-BOTTOM-COLOR:${bdcolor}; BACKGROUND-COLOR:${bgcolor1}; BORDER-TOP-COLOR: ${bdcolor}; BORDER-RIGHT-COLOR: ${bdcolor}; BORDER-LEFT-COLOR:${bdcolor}" class=cb1>&nbsp;</DIV><DIV style="BORDER-BOTTOM-COLOR:${bdcolor}; BORDER-TOP-COLOR:${bdcolor}; BORDER-RIGHT-COLOR:${bdcolor}; BORDER-LEFT-COLOR:${bdcolor}" class=cb2>&nbsp;</DIV></DIV>',
            __ALLDAYEVENTTEMP = '<div class="rb-o ${eclass}" id="${id}" title1="${title}" style="color:${color};"><div class="dhdV" style="display:none">${data}</div><div class="${extendClass} rb-m" style="background-color:${color}"><div class="rb-i t-title ${userEdition}">${content}</div><div class="rb-i t-loc">${location}</div><div class="rb-i t-desc">${description}</div></div></div>',
            __MonthDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
            __LASSOTEMP = "<div class='drag-lasso' style='left:${left}px;top:${top}px;width:${width}px;height:${height}px;'>&nbsp;</div>",
            __VIEWWEEKDAYS = option.viewWeekDays,
            __VIEWWEEKDAYSTOTAL = 0,
            _dragdata, _dragevent;
        for (i = 0; i < __VIEWWEEKDAYS.length; i++) __VIEWWEEKDAYSTOTAL += __VIEWWEEKDAYS[i];
        if (clearcontainer(), option.height || (option.height = document.documentElement.clientHeight), option.height / (option.hoursEnd - option.hoursStart + 1) > option.cellheight && (option.cellheight = Math.ceil(option.height / (option.hoursEnd - option.hoursStart + 1))), option.cellheight % 2 == 1 && option.cellheight++, option.url && option.autoload) {
            render();
            var d = getRdate();
            "list" != option.view && pushER(d.start, d.end), populate()
        } else {
            render();
            var d = getRdate();
            "list" != option.view && pushER(d.start, d.end)
        }

        function clearcontainer() {
            gridcontainer.empty()
        }

        function getRdate() {
            return {
                start: option.vstart,
                end: option.vend
            }
        }

        function pushER(t, e) {
            var a = option.loadDateR.length;
            if (e || (e = t), 0 == a) option.loadDateR.push({
                startdate: t,
                enddate: e
            });
            else {
                for (var o = 0; o < a; o++) {
                    var n = option.loadDateR[o],
                        i = DateDiff("d", t, n.startdate);
                    if (0 == i || 1 == i) {
                        n.enddate < e && (n.enddate = e);
                        break
                    }
                    if (i > 1) {
                        (s = DateDiff("d", e, n.startdate)) > 1 ? option.loadDateR.splice(0, 0, {
                            startdate: t,
                            enddate: e
                        }) : (n.startdate = t, n.enddate < e && (n.enddate = e));
                        break
                    }
                    var r = DateDiff("d", e, n.startdate);
                    if (n.enddate < e) {
                        if (r < 1) {
                            n.enddate = e;
                            break
                        }
                        o == a - 1 && option.loadDateR.push({
                            startdate: t,
                            enddate: e
                        })
                    }
                }
                if ((a = option.loadDateR.length) > 1)
                    for (o = 0; o < a - 1;) {
                        var d = option.loadDateR[o],
                            s = option.loadDateR[o + 1];
                        DateDiff("d", s.startdate, d.enddate) <= 1 ? (d.startdate = s.startdate > d.startdate ? d.startdate : s.startdate, d.enddate = s.enddate > d.enddate ? s.enddate : d.enddate, option.loadDateR.splice(o + 1, 1), a--) : o++
                    }
            }
        }

        function adaptWH() {
            $(".multicalendar").each((function() {
                var t = 0;
                $(this).find(".ui-datepicker-group").each((function() {
                    t < 1 * $(this).css("height").replace("px", "") && (t = 1 * $(this).css("height").replace("px", ""))
                })), 0 != t && $(this).find(".ui-datepicker-group").each((function() {
                    $(this).css("height", t + "px")
                }))
            }))
        }

        function render() {
            if ("list" == option.view ? $("#sfprevbtn" + option.thecontainer + ",#sfnextbtn" + option.thecontainer).addClass("nav_list") : $("#sfprevbtn" + option.thecontainer + ",#sfnextbtn" + option.thecontainer).removeClass("nav_list"), "" != option.mindate && option.mindate > option.showday && (option.showday = option.mindate), "" != option.maxdate && option.maxdate < option.showday && (option.showday = option.maxdate), option.vstart && option.vend) {
                if ("month" == option.view || "nMonth" == option.view) {
                    if ("month" == option.view) var t = 1;
                    else t = option.numberOfMonths;
                    var e = new Date(option.showday.getFullYear(), option.showday.getMonth(), 1),
                        a = (option.showday.getMonth() + t) % 12,
                        o = option.showday.getFullYear() + Math.floor((option.showday.getMonth() + t) / 12),
                        n = new Date(o, a, 1);
                    n = DateAdd("d", -1, n)
                } else e = option.vstart, n = option.vend;
                option.mindate >= e && option.mindate <= n ? ($("#sfprevbtn" + option.thecontainer).find(".ui-icon-circle-triangle-w").css({
                    opacity: .3
                }), $("#sfprevbtn" + option.thecontainer).addClass("non-navigate")) : ($("#sfprevbtn" + option.thecontainer).find(".ui-icon-circle-triangle-w").css({
                    opacity: 1
                }), $("#sfprevbtn" + option.thecontainer).removeClass("non-navigate")), option.maxdate >= e && option.maxdate <= n ? ($("#sfnextbtn" + option.thecontainer).find(".ui-icon-circle-triangle-e").css({
                    opacity: .3
                }), $("#sfnextbtn" + option.thecontainer).addClass("non-navigate")) : ($("#sfnextbtn" + option.thecontainer).find(".ui-icon-circle-triangle-e").css({
                    opacity: 1
                }), $("#sfnextbtn" + option.thecontainer).removeClass("non-navigate"))
            }
            var i = new Date(option.showday.getFullYear(), option.showday.getMonth(), option.showday.getDate()),
                r = option.eventItems,
                d = {
                    view: option.view,
                    weekstartday: option.weekstartday,
                    theme: option.theme,
                    thecontainer: option.thecontainer
                };
            if ("day" == option.view || "week" == option.view || "nDays" == option.view || "rowMonth" == option.view) {
                var s = $("#dvtec" + option.thecontainer);
                s.length > 0 && (option.scoll = s.attr("scrollTop"))
            }
            switch (gridcontainer.parent().parent().width("100%"), $(".gridcontainercover").attr("class", "gridcontainercover view" + option.view), option.view) {
                case "day":
                    BuildDaysAndWeekView(i, 1, r, d), gridcontainer.height("auto");
                    break;
                case "week":
                    BuildDaysAndWeekView(i, 7, r, d), gridcontainer.height("auto");
                    break;
                case "month":
                    BuildMonthView(i, r, d), $("#gridcontainer" + option.thecontainer + " [display='0']").css("display", "none");
                    try {
                        var l = 0;
                        $("#gridcontainer" + option.thecontainer + " .month-row").each((function() {
                            var t = 1 * $(this).find(".st-grid").height(),
                                e = 1 * $(this).css("height").replace("px", "");
                            t > 0 && e < t && (e = t), $(this).css("height", e), $(this).css("top", l), l += e
                        })), $("#gridcontainer" + option.thecontainer + " .mv-event-container").css("height", l), $("#gridcontainer" + option.thecontainer + " .gridcontainercover").children().css("height", l + 1 * $(".mv-daynames-table").height() + 2)
                    } catch (t) {
                        console.log(t)
                    }
                    gridcontainer.css("overflow-y", "visible").height($("#mvEventContainer" + d.thecontainer).height() + 18);
                    break;
                case "rowMonth":
                    i = new Date(i.getFullYear(), i.getMonth(), 1);
                    var p = DateAdd("d", 40, i);
                    p = new Date(p.getFullYear(), p.getMonth(), 1);
                    var c = (p = DateAdd("d", -1, p)).getDate();
                    option.nOfDays = c, BuildDaysAndWeekView(i, option.nOfDays, r, d), gridcontainer.height("auto");
                    break;
                case "nDays":
                    option.nOfDays = option.numberOfDays, BuildDaysAndWeekView(i, option.nOfDays, r, d), gridcontainer.height("auto");
                    break;
                case "list":
                    BuildListView(i, option.list_eventsPerPage, r, d), gridcontainer.height("auto");
                    break;
                case "nMonth":
                    BuildYearView(i, r, d), gridcontainer.css("overflow-y", "visible");
                    var h = gridcontainer.width() - 2;
                    if (1 == option.numberOfMonths) 0 != option.newWidthGroup ? (gridcontainer.parent().parent().parent().width(option.newWidthGroup), gridcontainer.children().children().width(option.newWidthGroup - 12)) : (option.newWidthGroupCalculate = !0, gridcontainer.parent().parent().width($("#nmonths" + option.thecontainer).children().width() + 12));
                    else if (0 != option.newWidthGroup) $("#nmonths" + option.thecontainer).find(".ui-datepicker-multi").width(h), $("#nmonths" + option.thecontainer).find(".ui-datepicker-multi .ui-datepicker-group").width(option.newWidthGroup);
                    else {
                        option.newWidthGroupCalculate = !0, $("#nmonths" + option.thecontainer).find(".ui-datepicker-multi").width(h);
                        var u = 2e3;
                        $("#nmonths" + option.thecontainer).find(".ui-datepicker-group .ui-datepicker-calendar").each((function(t) {
                            u > $(this).width() && (u = $(this).width())
                        })), u += 4;
                        var v = 0 == Math.floor(h / u) ? 1 : Math.floor(h / u),
                            m = Math.floor(h / v);
                        m -= 4, option.newWidthGroup = m, $("#nmonths" + option.thecontainer).find(".ui-datepicker-multi .ui-datepicker-group").width(m)
                    }
                    gridcontainer.height($("#nmonths" + option.thecontainer).height());
                    break;
                default:
                    alert(i18n.dcmvcal.no_implemented)
            }
            if (initevents(option.view), ResizeView(option), !("" == option.rowsList || option.dayWithTime && "day" == option.view))
                for (var g = 0; g < option.rowsList.length; g++) Math.round((option.height - 50) / option.rowsList.length) > $("#weekViewAllDaywk" + option.thecontainer + g + " table").height() && $("#weekViewAllDaywk" + option.thecontainer + g).height(Math.round((option.height - 50) / option.rowsList.length));
            $(document).trigger("afterRenderMV", {
                option: option
            })
        }

        function BuildYearView(t, e, a) {
            var o = new Date(t.getFullYear(), t.getMonth(), 1),
                n = (t.getMonth() + option.numberOfMonths) % 12,
                r = t.getFullYear() + Math.floor((t.getMonth() + option.numberOfMonths) / 12),
                d = new Date(r, n, 1);
            d = DateAdd("d", -1, d), option.vstart = o, option.vend = d, option.datestrshow = CalDateShow(option.vstart, option.vend);
            var s = [];
            s.push('<div id="nmonths' + a.thecontainer + '" class="nmonths" >'), s.push("</div>"), gridcontainer.html(s.join(""));
            {
                var l = [];
                for (i = 0; i < e.length; i++) {
                    var p = e[i][2];
                    p = new Date(p.getFullYear(), p.getMonth(), p.getDate());
                    var c = e[i][3];
                    c = new Date(c.getFullYear(), c.getMonth(), c.getDate());
                    for (var u = ""; p <= c;) u = p.getFullYear() + "/" + (p.getMonth() + 1) + "/" + p.getDate(), l[u] || (l[u] = []), l[u][l[u].length] = e[i], p = DateAdd("d", 1, p)
                }
                try {
                    var v = $.datepicker._updateDatepicker;
                    $.datepicker._updateDatepicker = function(t) {
                        v.call(this, t), adaptWH()
                    }
                } catch (f) {}
                $("#nmonths" + option.thecontainer).datepicker({
                    numberOfMonths: option.numberOfMonths,
                    firstDay: option.weekstartday,
                    defaultDate: t,
                    showOtherMonths: !0,
                    monthNamesShort: __MonthName,
                    monthNames: __MonthNameLarge,
                    dayNamesShort: __WDAY,
                    dayNamesMin: __WDAY2,
                    onChangeMonthYear: function(t, e, a) {
                        if ($(this).datepicker("getDate") > new Date(t, e - 1, 1)) var o = $("#gridcontainer" + option.thecontainer).previousRange().BcalGetOp();
                        else o = $("#gridcontainer" + option.thecontainer).nextRange().BcalGetOp();
                        o && o.datestrshow && $("#txtdatetimeshow" + option.thecontainer).text(o.datestrshow)
                    },
                    beforeShowDay: function(t) {
                        if (0 == __VIEWWEEKDAYS[0] && 0 == t.getDay()) return [!0, "specialday"];
                        if (0 == __VIEWWEEKDAYS[1] && 1 == t.getDay()) return [!0, "specialday"];
                        if (0 == __VIEWWEEKDAYS[2] && 2 == t.getDay()) return [!0, "specialday"];
                        if (0 == __VIEWWEEKDAYS[3] && 3 == t.getDay()) return [!0, "specialday"];
                        if (0 == __VIEWWEEKDAYS[4] && 4 == t.getDay()) return [!0, "specialday"];
                        if (0 == __VIEWWEEKDAYS[5] && 5 == t.getDay()) return [!0, "specialday"];
                        if (0 == __VIEWWEEKDAYS[6] && 6 == t.getDay()) return [!0, "specialday"];
                        var e = t.getFullYear() + "/" + (t.getMonth() + 1) + "/" + t.getDate();
                        return l[e] ? [!0, "ui-state-active", dateFormat.call(t, i18n.dcmvcal.dateformat.fulldayvalue)] : [!0, "ui-state-non-active", dateFormat.call(t, i18n.dcmvcal.dateformat.fulldayvalue)]
                    }
                });
                if (0 == __VIEWWEEKDAYS[0] && $(".ui-datepicker span[title='Sunday']").parent().css("display", "none"), 0 == __VIEWWEEKDAYS[1] && $(".ui-datepicker span[title='Monday']").parent().css("display", "none"), 0 == __VIEWWEEKDAYS[2] && $(".ui-datepicker span[title='Tuesday']").parent().css("display", "none"), 0 == __VIEWWEEKDAYS[3] && $(".ui-datepicker span[title='Wednesday']").parent().css("display", "none"), 0 == __VIEWWEEKDAYS[4] && $(".ui-datepicker span[title='Thursday']").parent().css("display", "none"), 0 == __VIEWWEEKDAYS[5] && $(".ui-datepicker span[title='Friday']").parent().css("display", "none"), 0 == __VIEWWEEKDAYS[6] && $(".ui-datepicker span[title='Saturday']").parent().css("display", "none"), $("#nmonths" + option.thecontainer + " .ui-datepicker-other-month").attr("title", ""), option.date_box_with_color_in_nmonth_view) {
                    var m = parseInt($("#nmonths" + option.thecontainer + " .ui-state-active").css("height"));
                    $("#nmonths" + option.thecontainer + " .ui-state-active").each((function() {
                        try {
                            var t = datetostr(strtodate($(this).attr("title") + " 00:00"));
                            if (t && l[t] && l[t].length > 0) {
                                for (var e = new Array, a = "", o = "#" + option.paletteDefault, n = 0; n < l[t].length; n++) o = -1 != l[t][n][7] && null != l[t][n][7] ? l[t][n][7] : "#" + option.paletteDefault, -1 == $.inArray(o, e) && (e[e.length] = o);
                                if (1 == e.length) $(this).attr("style", "background:" + e[e.length - 1] + " !important");
                                else {
                                    var i = e.length;
                                    $(this).css("vertical-align", "top"), a += '<div style="position:relative;border:0px solid;padding:0px;margin:0px;height:' + m + 'px;">';
                                    var r = 0;
                                    for (n = 0; n < i; n++) h = Math.round(m / i * (n + 1)) - r, a += '<div style="position:absolute;margin:0px;padding:0px;border:0px solid;width:100%;background:' + e[n] + ";height:" + h + "px;top:" + r + 'px;left:0px;"></div>', r = Math.round(m / i * (n + 1));
                                    a += '<div style="position:absolute;margin:0px;padding:0px;border:0px solid;width:100%;background:transparent;white-space: nowrap;height:' + m + 'px;top:0px;left:0px;">' + $(this).html() + "</div>", a += "</div>", $(this).html(a)
                                }
                            }
                        } catch (t) {}
                    }))
                }

                function g(t, e, a) {
                    var o = e.split("/"),
                        n = new Date(o[0], o[1] - 1, o[2]);
                    title = dateFormat.call(n, i18n.dcmvcal.dateformat.fulldayshow);
                    var i = "",
                        r = "",
                        d = "",
                        s = "",
                        l = "",
                        p = "",
                        c = !0;
                    if (t[e]) {
                        for (o = 0; o < t[e].length; o++) {
                            if (d = dateFormat.call(t[e][o][2], i18n.dcmvcal.dateformat.fulldayshow), l = fomartTimeAMPM(t[e][o][2].getHours(), t[e][o][2].getMinutes(), __MilitaryTime), s = dateFormat.call(t[e][o][3], i18n.dcmvcal.dateformat.fulldayshow), p = fomartTimeAMPM(t[e][o][3].getHours(), t[e][o][3].getMinutes(), __MilitaryTime), d == s ? (r = '<div class="mv_dlg_nmonth_date">' + d + "</div>", 1 != t[e][o][4] && (r += " " + l)) : (c = !1, r = 1 != t[e][o][4] ? '<div class="mv_dlg_nmonth_date">' + d + "</div> " + l + ' - <div class="mv_dlg_nmonth_date">' + s + "</div> " + p : '<div class="mv_dlg_nmonth_date">' + d + " - " + s + "</div>"), 1 != option.readonly && (option.userEdit || option.userDel || option.userOwner == t[e][o][12] && (option.userEditOwner || option.userDelOwner))) var h = "dialogNMonth_event";
                            else h = "";
                            i += '<div class="' + h + '"><div class="dialogNMonth_event_links">', i += '</div><div class="dialogNMonth_event_content" style="border-left:3px solid ' + (-1 != t[e][o][7] && null != t[e][o][7] ? t[e][o][7] : "#" + option.paletteDefault) + ';">' + r + "<div>" + t[e][o][1] + "</div>" + ("" != t[e][o][9] && null != t[e][o][9] ? "<div>" + t[e][o][9] + "</div>" : "") + ("" != t[e][o][11] && "<br />" != t[e][o][11] && null != t[e][o][11] ? "<div>" + t[e][o][11] + "</div>" : "") + "</div></div>"
                        }
                        try {
                            $("#bbit-cs-buddle").dialog("close")
                        } catch (t) {}
                        try {
                            $(".mv_dlg_nmonth").dialog("close")
                        } catch (t) {}
                        c && (i = '<div class="mv_dlg_nmonth_title">' + title + "</div>" + i), $(a).html(i), $(".mv_dlg_nmonth_date").css("font-weight", "bold"), c ? $(".mv_dlg_nmonth_date").css("display", "none") : $(".mv_dlg_nmonth_date").css("display", "inline");
                        try {
                            $(a).dialog("option", "title", title)
                        } catch (t) {}
                        for (o = 0; o < t[e].length; o++) $("#editlink" + t[e][o][0]).data("cdata", t[e][o]), $("#dellink" + t[e][o][0]).data("cdata", t[e][o]);
                        $("#createlink").data("cdata", n), $(".dlgNMonth_createlink").click((function(t) {
                            try {
                                $(".mv_dlg_nmonth").dialog("close")
                            } catch (t) {}
                            return option.EditCmdhandler && $.isFunction(option.EditCmdhandler) && option.EditCmdhandler.call(this, ["0", "", $("#createlink").data("cdata"), $("#createlink").data("cdata"), 1]), realsedragevent(), t.stopPropagation(), !1
                        })), $(".dlgNMonth_editlink").click((function(t) {
                            try {
                                $(".mv_dlg_nmonth").dialog("close")
                            } catch (t) {}
                            return option.EditCmdhandler && $.isFunction(option.EditCmdhandler) && option.EditCmdhandler.call(this, $("#" + $(this).attr("id")).data("cdata")), realsedragevent(), t.stopPropagation(), !1
                        })), $(".dlgNMonth_dellink").bind("click", (function(t) {
                            try {
                                $(".mv_dlg_nmonth").dialog("close")
                            } catch (t) {}
                            return option.DeleteCmdhandler && $.isFunction(option.DeleteCmdhandler) && option.DeleteCmdhandler.call(this, $("#" + $(this).attr("id")).data("cdata"), quickd), realsedragevent(), t.stopPropagation(), !1
                        })), $(a).dialog("open"), dialogUnBlur(), move_mv_dlg()
                    }
                }
                $("#nmonths" + option.thecontainer + " .ui-state-active a").bind("click", (function(t) {
                    if (0 == __VIEWWEEKDAYS[0] && $(".ui-datepicker span[title='Sunday']").parent().css("display", "none"), 0 == __VIEWWEEKDAYS[1] && $(".ui-datepicker span[title='Monday']").parent().css("display", "none"), 0 == __VIEWWEEKDAYS[2] && $(".ui-datepicker span[title='Tuesday']").parent().css("display", "none"), 0 == __VIEWWEEKDAYS[3] && $(".ui-datepicker span[title='Wednesday']").parent().css("display", "none"), 0 == __VIEWWEEKDAYS[4] && $(".ui-datepicker span[title='Thursday']").parent().css("display", "none"), 0 == __VIEWWEEKDAYS[5] && $(".ui-datepicker span[title='Friday']").parent().css("display", "none"), 0 == __VIEWWEEKDAYS[6] && $(".ui-datepicker span[title='Saturday']").parent().css("display", "none"), option.shownavigate) {
                        var e = datetostr(strtodate($(this).parents(".ui-state-active").attr("title") + " 00:00")).split("/"),
                            a = new Date(e[0], e[1] - 1, e[2]);
                        a = dateFormat.call(a, i18n.dcmvcal.dateformat.fulldayvalue);
                        var o = option.navigateurl.replace(/the_current_date/g, a);
                        1 == option.target ? document.location = o : window.open(o)
                    }
                    return t.stopPropagation(), !1
                })), $("#nmonths" + option.thecontainer + " .ui-state-non-active a").bind("click", (function(t) {
                    var e = datetostr(strtodate($(this).parent().attr("title") + " 00:00")).split("/"),
                        a = new Date(e[0], e[1] - 1, e[2]);
                    return quickadd(a, a, !0, {
                        left: t.pageX,
                        top: t.pageY
                    }), t.stopPropagation(), !1
                })), (option.showtooltip || 1 != option.readonly) && (0 != option.tooltipon ? $("#nmonths" + option.thecontainer + " .ui-state-active a").bind("click", (function(t) {
                    var e = datetostr(strtodate($(this).parents(".ui-state-active").attr("title") + " 00:00")),
                        a = "myover" + e.replace(/\//g, "_");
                    $(".ui-dialog-content").remove(), $(this).parent().append('<div class="' + a + '" ></div>'), $(a = "." + a).dialog({
                        autoOpen: !1,
                        width: option.dialogWidth,
                        modal: !1,
                        resizable: !1,
                        maxWidth: option.dialogWidth,
                        fluid: !0,
                        open: function(t, e) {
                            fluidDialog()
                        },
                        position: {
                            my: "left top",
                            at: "center bottom",
                            collision: "fit",
                            of: $(a).parent()
                        }
                    }).addClass("mv_dlg_nmonth").parent().addClass("mv_dlg"), $('<div id="mv_corner" />').appendTo($(".mv_dlg .ui-dialog-titlebar")), g(l, e, a), t.stopPropagation()
                })).bind("mouseout", (function() {})) : 0 == option.tooltipon && $("#nmonths" + option.thecontainer + " .ui-state-active").bind("mouseover", (function() {
                    if (!$(this).hasClass("ui-datepicker-other-month")) {
                        $(".ui-dialog-content").remove(), $(this).append('<div class="myover" ></div>'), $(".myover").dialog({
                            autoOpen: !1,
                            width: option.dialogWidth,
                            modal: !1,
                            resizable: !1,
                            maxWidth: option.dialogWidth,
                            fluid: !0,
                            open: function(t, e) {
                                fluidDialog()
                            },
                            position: {
                                my: "left top",
                                at: "center bottom",
                                collision: "fit",
                                of: $(".myover").parent()
                            }
                        }).addClass("mv_dlg_nmonth").parent().addClass("mv_dlg"), $('<div id="mv_corner" />').appendTo($(".mv_dlg .ui-dialog-titlebar"));
                        try {
                            var t = datetostr(strtodate($(this).attr("title") + " 00:00"));
                            g(l, t, ".myover")
                        } catch (t) {}
                    }
                })).bind("mouseout", (function() {})), $(".mv_dlg_nmonth").remove())
            }
        }

        function BuildListView(t, e, a, o) {
            var n = option.list_totalEvents > 0 && a.length > option.list_totalEvents ? a.slice(0, option.list_totalEvents) : a.slice();
            option.allevents = n.slice(), option.theme_list && "" != option.theme_list || (option.theme_list = '<div><div class="list_event_content" style="border-left:3px solid ${color};"><div class="list_event_date" option="1${option}"><div class="list_date">${date_start}</div></div><div class="list_event_date" option="2${option}"><div class="list_date">${date_start}</div><div class="list_time">${time_start} - ${time_end}</div></div><div class="list_event_date" option="3${option}"><div class="list_date">${date_start} - ${date_end}</div></div><div class="list_event_date" option="4${option}"><div class="list_date">${date_start}</div><div class="list_time">${time_start}</div> - <div class="list_date">${date_end}</div><div class="list_time">${time_end}</div></div><div class="itemlist_title">${title}</div><div class="itemlist_location">${location}</div><div class="itemlist_description" readmore_url="">${description}</div><div class="itemlist_edit">${edit_link}</div><div class="itemlist_delete">${delete_link}</div></div></div>'), option.theme_list = option.theme_list.replace(/\n/g, ""), option.theme_list = option.theme_list.replace(/\r/g, ""), option.header || (option.header = ""), option.footer || (option.footer = ""), option.find || (option.find = "");
            var i = option.theme_list.match("<header>(.*)</header>");
            i && i.length > 1 && (option.header = i[1]), option.theme_list = option.theme_list.replace(/<header>(.*)<\/header>/, "");
            var r = option.theme_list.match("<find>(.*)</find>");
            r && r.length > 1 && (option.find = r[1].split(",")), option.theme_list = option.theme_list.replace(/<find>(.*)<\/find>/, "");
            var d = option.theme_list.match("<footer>(.*)</footer>");
            d && d.length > 1 && (option.footer = d[1]), option.theme_list = option.theme_list.replace(/<footer>(.*)<\/footer>/, ""), option.vstart = t, option.vend = t;
            var s = {},
                l = [];

            function p() {
                if (null != option.searchvalue && "" != option.searchvalue)
                    for (var t = n.length - 1; t >= 0; t--) - 1 != n[t][1].toLowerCase().indexOf(option.searchvalue) || -1 != n[t][9].toLowerCase().indexOf(option.searchvalue) || null != n[t][11] && -1 != n[t][11].toLowerCase().indexOf(option.searchvalue) || n.splice(t, 1);
                var e = "",
                    a = 0,
                    o = !1;
                if (option.cachepages.length > option.page) return option.cachepages[option.page];
                for (t = 0; t < n.length; t++) {
                    o = !1, s.date_start = dateFormat.call(n[t][2], i18n.dcmvcal.dateformat.fulldayshow), s.date_start_year = dateFormat.call(n[t][2], "yyyy"), s.date_start_month = dateFormat.call(n[t][2], "MM"), s.date_start_day = dateFormat.call(n[t][2], "dd"), s.date_start_monthName = __MonthName[n[t][2].getMonth()], s.date_start_monthNameLarge = __MonthNameLarge[n[t][2].getMonth()], s.date_start_weekday = __WDAYLarge[n[t][2].getDay()], s.time_start = fomartTimeAMPM(n[t][2].getHours(), n[t][2].getMinutes(), __MilitaryTime), s.date_end = dateFormat.call(n[t][3], i18n.dcmvcal.dateformat.fulldayshow), s.date_end_year = dateFormat.call(n[t][3], "yyyy"), s.date_end_month = dateFormat.call(n[t][3], "MM"), s.date_end_day = dateFormat.call(n[t][3], "dd"), s.date_end_monthName = __MonthName[n[t][3].getMonth()], s.date_end_monthNameLarge = __MonthNameLarge[n[t][3].getMonth()], s.date_end_weekday = __WDAYLarge[n[t][3].getDay()], s.time_end = fomartTimeAMPM(n[t][3].getHours(), n[t][3].getMinutes(), __MilitaryTime), s.date_start == s.date_end ? (s.option = 1, 1 != n[t][4] && (s.option = 2)) : 1 != n[t][4] ? s.option = 4 : s.option = 3;
                    var i = "";
                    if ("" != n[t][11] && "<br />" != n[t][11] && null != n[t][11])
                        if (0 == option.list_readmore_numberofwords) i = n[t][11];
                        else {
                            var r = $.trim(n[t][11]);
                            r = $("<div/>").html(r).text();
                            if (words = r.replace(/\s+/gi, " ").split(" "), words.length > option.list_readmore_numberofwords) {
                                r = "";
                                for (var d = 0; d < option.list_readmore_numberofwords; d++) r += " " + words[d];
                                i = '<div class="description_short">' + $.trim(r) + ' ... <a href="" class="readmore short">' + i18n.dcmvcal.readmore + "</a></div>", i += '<div class="description_large">' + n[t][11] + ' <a href="" class="readmore large">' + i18n.dcmvcal.readmore_less + "</a></div>"
                            } else r = n[t][11], i = n[t][11]
                        } s.id = n[t][0], s.color = -1 != n[t][7] && null != n[t][7] ? n[t][7] : "#" + option.paletteDefault, s.title = n[t][1], s.location = "" != n[t][9] && null != n[t][9] ? n[t][9] : "", s.description = i, s.edit_link = "", s.delete_link = "", 1 != option.readonly && (option.userEdit || option.userDel || option.userOwner == n[t][12] && (option.userEditOwner || option.userDelOwner)) && ((option.userDel || option.userOwner == n[t][12] && option.userDelOwner) && ("" != n[t][6] && null != n[t][6] && null != n[t][6] || (s.edit_link = '<a class="edit_link_ev" href="">' + i18n.dcmvcal.update_detail + "</a>")), (option.userEdit || option.userOwner == n[t][12] && option.userEditOwner) && (s.delete_link = '<a class="delete_link_ev" href="">' + i18n.dcmvcal.i_delete + "</a>")), 0 == t && "" != option.header && (e = '<div class="headerlist">' + Tp(option.header, s) + "</div>"), a++;
                    var l = "" != n[t][6] && null != n[t][6] && null != n[t][6];
                    if ("" != option.lastdate && (!l && n[t][0] == option.currentlist.idend || l && n[t][2].toString() == option.currentlist.dend.toString()) && (a = 0, e = "", "" != option.header && (e = '<div class="headerlist">' + Tp(option.header, s) + "</div>"), o = !0), a <= option.list_eventsPerPage && !o) {
                        var p = Tp(option.theme_list, s);
                        p = '<div class="ev_item_data" i="' + t + '">' + p + "</div>";
                        for (var c = 0; c < option.find.length; c++) - 1 != p.toLowerCase().indexOf(option.find[c].toLowerCase()) && (p = p.replace("find_and_replace", "find_and_replace " + option.find[c]));
                        e += p, eMax = t
                    }
                }
                return a > 0 && (0 == option.list_totalEvents || option.list_totalEvents > option.list_eventsPerPage) && (option.currentlist = {
                    dend: n[eMax][2],
                    idend: n[eMax][0]
                }, e += '<div class="listnav">', e += '<a href="#" id="listprevbtn' + option.thecontainer + '" class="listprevbtn ' + (0 == option.page ? "listbtndisabled" : "") + '">' + i18n.dcmvcal.prev + "</a>", e += '<a href="#" id="listnextbtn' + option.thecontainer + '" class="listnextbtn ' + (n.length - 1 == eMax ? "listbtndisabled" : "") + '">' + i18n.dcmvcal.next + "</a>", e += '<div style="clear:both"></div></div>'), "" != e && (option.cachepages[option.page] = e), e
            }

            function c() {
                $("#gridcontainer" + option.thecontainer).find(".ev_item_data").each((function() {
                    $(this).data("cdata", n[1 * $(this).attr("i")])
                })), $("#gridcontainer" + option.thecontainer).find(".delete_link_ev").click((function() {
                    var t = $(this).parents(".ev_item_data").data("cdata");
                    return option.DeleteCmdhandler && $.isFunction(option.DeleteCmdhandler) && (option.page = 0, option.lastdate = "", option.currentlist = {
                        dend: "",
                        idend: 0
                    }, option.cachepages = new Array, option.DeleteCmdhandler.call(this, t, quickd)), !1
                })), $("#gridcontainer" + option.thecontainer).find(".edit_link_ev").click((function(t) {
                    if (option.EditCmdhandler) {
                        if (option.EditCmdhandler && $.isFunction(option.EditCmdhandler)) {
                            option.page = 0, option.lastdate = "", option.currentlist = {
                                dend: "",
                                idend: 0
                            }, option.cachepages = new Array;
                            var e = $(this).parents(".ev_item_data").data("cdata");
                            option.EditCmdhandler.call(this, e)
                        }
                    } else alert("EditCmdhandler" + i18n.dcmvcal.i_undefined);
                    return !1
                })), $("#gridcontainer" + option.thecontainer).find("#listprevbtn" + option.thecontainer).click((function() {
                    return $(this).hasClass("listbtndisabled") || $("#gridcontainer" + option.thecontainer).previousRange().BcalGetOp(), !1
                })), $("#gridcontainer" + option.thecontainer).find("#listnextbtn" + option.thecontainer).click((function() {
                    return $(this).hasClass("listbtndisabled") || $("#gridcontainer" + option.thecontainer).nextRange().BcalGetOp(), !1
                })), $("#gridcontainer" + option.thecontainer).find("#listcontainer" + option.thecontainer).find(".list_event_date").each((function() {
                    "11" != $(this).attr("option") && "22" != $(this).attr("option") && "33" != $(this).attr("option") && "44" != $(this).attr("option") && $(this).css("display", "none")
                })), $("#gridcontainer" + option.thecontainer).find("#listcontainer" + option.thecontainer).find(".readmore").click((function() {
                    return "" == $(this).parent().parent().attr("readmore_url") ? $(this).hasClass("short") ? ($(this).parent().parent().find(".description_short").css("display", "none"), $(this).parent().parent().find(".description_large").css("display", "block")) : ($(this).parent().parent().find(".description_short").css("display", "block"), $(this).parent().parent().find(".description_large").css("display", "none")) : document.location = $(this).parent().parent().attr("readmore_url"), !1
                }))
            }
            null == option.searchvalue && (option.searchvalue = ""), l.push('<div id="searchcontainer' + o.thecontainer + '" class="searchcontainer"><input type="text" placeholder="Enter search term" value="' + option.searchvalue + '"></div>'), l.push('<div id="listcontainer' + o.thecontainer + '" class="listcontainer">'), l.push(p()), l.push("</div>"), option.datestrshow = " ", gridcontainer.html(l.join("")), $("#gridcontainer" + option.thecontainer).find(".searchcontainer input").keyup((function() {
                return option.searchvalue = $(this).val().toLowerCase(), option.page = 0, option.lastdate = "", option.currentlist = {
                    dend: "",
                    idend: 0
                }, option.cachepages = new Array, n = option.allevents.slice(), $("#listcontainer" + o.thecontainer).html(p()), c(), !1
            })), c(), l = null
        }

        function BuildDaysAndWeekView(t, e, a, o) {
            var n = [];
            if (1 == e) {
                var i = dateFormat.call(t, i18n.dcmvcal.dateformat.Md);
                n.push({
                    display: i,
                    date: t,
                    day: t.getDate(),
                    year: t.getFullYear(),
                    month: t.getMonth() + 1
                }), option.datestrshow = CalDateShow(n[0].date), option.vstart = n[0].date, option.vend = n[0].date
            } else {
                var r, d = 0;
                if (7 == e) {
                    (d = o.weekstartday - t.getDay()) > 0 && (d -= e);
                    var s = i18n.dcmvcal.dateformat.Md
                } else if ("rowMonth" == option.view) s = i18n.dcmvcal.dateformat.day;
                else s = i18n.dcmvcal.dateformat.nDaysView;
                for (var l = d, p = 0; p < e; l += 1, p++) {
                    r = DateAdd("d", l, t);
                    i = dateFormat.call(r, s);
                    n.push({
                        display: i,
                        date: r,
                        day: r.getDate(),
                        year: r.getFullYear(),
                        month: r.getMonth() + 1
                    })
                }
                option.vstart = n[0].date, option.vend = n[e - 1].date, option.datestrshow = CalDateShow(n[0].date, n[e - 1].date)
            }
            var c = [],
                h = [],
                u = [];
            if (u.push('<div id="dvwkcontaienr' + o.thecontainer + '" class="wktopcontainer">'), u.push('<table class="wk-top" border="0" cellpadding="0" cellspacing="0" >'), "" != option.columnsList && "day" == option.view) {
                u.push('<tr><th width="' + option.hourswidth + '" class="wk-dayWithColumns">' + n[0].display + "</th>");
                for (l = 0; l < option.columnsList.length; l++) u.push("<th abbr='", dateFormat.call(n[0].date, "M/d/yyyy"), "' class='gcweekname' scope=\"col\"><div title='", "' ", " class='wk-dayname'><span class='", "'>", option.columnsList[l], "</span></div></th>");
                u.push('<th width="16" >&nbsp;</th></tr>')
            } else "" == option.rowsList || option.dayWithTime && "day" == option.view ? (u.push('<tr><th width="' + option.hourswidth + '" rowspan="2">&nbsp;</th>'), BuildWTHeader(u, n), u.push('<th width="16" rowspan="2">&nbsp;</th></tr>')) : (u.push('<tr><th width="' + option.hourswidth + '">&nbsp;</th>'), BuildWTHeader(u, n), u.push('<th width="16">&nbsp;</th></tr>'));
            if ("" == option.rowsList || option.dayWithTime && "day" == option.view) {
                var v = PropareEvents(n, a, c, h, "");
                "" != option.columnsList && "day" == option.view ? (u.push('<tr><th width="' + option.hourswidth + '" >&nbsp;</th>'), BuildWTBodyDayWithCol(u, n, c, v, o, 0)) : (u.push("<tr>"), BuildWTBody(u, n, c, v, o, ""))
            } else
                for (var m = 0; m < option.rowsList.length; m++) {
                    u.push('<tr><th width="60" class="wk-alldayList">' + option.rowsList[m] + "</th>");
                    v = PropareEvents(n, a, c, h, option.rowsList[m], "");
                    "" != option.columnsList && "day" == option.view ? BuildWTBodyDayWithCol(u, n, c, v, o, m) : BuildWTBody(u, n, c, v, o, m, "")
                }
            u.push("</table>"), u.push("</div>"), ("" == option.rowsList || option.dayWithTime && "day" == option.view) && (u.push('<div id="dvtec' + o.thecontainer + '"  class="scolltimeevent"><table style="table-layout: fixed;', $.tzfdbrowser.msie ? "" : "width:100%", '" cellspacing="0" cellpadding="0"><tbody><tr><td>'), u.push('<table style="height: ' + (option.hoursEnd - option.hoursStart + 1) * option.cellheight + 'px" id="tgTable' + o.thecontainer + '" class="tg-timedevents" cellspacing="0" cellpadding="0"><tbody>'), BuildDayScollEventheader(u, n, h, o), "" != option.columnsList && "day" == option.view ? BuildDayScollEventbodyWithCol(u, n, h, o) : BuildDayScollEventbody(u, n, h, o), u.push("</tbody></table></td></tr></tbody></table></div>")), gridcontainer.html(u.join("")), u = null
        }

        function BuildMonthView(t, e, a) {
            var o = "<div id='cal-month-cc" + a.thecontainer + "' class='cc'><div id='cal-month-cc-header" + a.thecontainer + "'><div class='cc-close' id='cal-month-closebtn" + a.thecontainer + "'></div><div id='cal-month-cc-title" + a.thecontainer + "' class='cc-title'></div></div><div id='cal-month-cc-body" + a.thecontainer + "' class='cc-body'><div id='cal-month-cc-content" + a.thecontainer + "' class='st-contents'><table class='st-grid' cellSpacing='0' cellPadding='0'><tbody></tbody></table></div></div></div>",
                n = [];
            n.push(o), n.push('<div id="mvcontainer' + a.thecontainer + '" class="mv-container">'), n.push('<table id="mvweek' + a.thecontainer + '" class="mv-daynames-table" cellSpacing="0" cellPadding="0"><tbody><tr>');
            for (var i = a.weekstartday, r = 0; r < 7; i++, r++) {
                i > 6 && (i = 0);
                __WDAY[i];
                0 != __VIEWWEEKDAYS[i] && n.push('<th class="mv-dayname" title="', __WDAY[i], '">', __WDAY[i], "")
            }
            n.push("</tr></tbody></table>"), n.push("</div>");
            var d = GetMonthViewBodyHeight() - GetMonthViewHeaderHeight();
            n.push('<div id="mvEventContainer' + a.thecontainer + '" class="mv-event-container" style="top:18px;height:', d, "px;", '">'), BuilderMonthBody(n, t, a.weekstartday, e, d, a), n.push("</div>"), gridcontainer.html(n.join("")), n = null, $("#cal-month-closebtn" + a.thecontainer).click(closeCc)
        }

        function closeCc() {
            $("#cal-month-cc" + option.thecontainer).css("visibility", "hidden")
        }

        function PropareEvents(t, e, a, o, n) {
            var i = t.length,
                r = e.length,
                d = [],
                s = a,
                l = o,
                p = t[0].date,
                c = t[t.length - 1].date;
            c = new Date(c.getFullYear(), c.getMonth(), c.getDate(), 23, 59, 59);
            for (var h = 0; h < r; h++) {
                var u = e[h][2],
                    v = e[h][3];
                if (DateDiff("d", u, v) > 0 && 1 != e[h][4] && !(option.rowsList.length > 0 && "week" == option.view)) {
                    u < p && (u = p), v > c && (v = c);
                    for (; u <= v; u = DateAdd("d", 1, u)) {
                        (m = {}).event = e[h], m.day = u.getDate(), m.year = u.getFullYear(), m.month = u.getMonth() + 1, "" == option.rowsList || option.dayWithTime && "day" == option.view ? m.allday = 1 == e[h][4] : m.allday = 1, m.crossday = 1 == e[h][5], m.reevent = e[h][6], m.daystr = [m.year, m.month, m.day].join("/"), m.noResizer = !0, m.st = {}, u > e[h][2] ? (m.st.hour = 0, m.st.minute = 0, m.noStarttime = !0) : (m.st.hour = u.getHours(), m.st.minute = u.getMinutes()), m.st.p = 60 * m.st.hour + m.st.minute, m.et = {}, DateAdd("d", 1, u) < e[h][3] ? (m.et.hour = 23, m.et.minute = 59) : (m.et.hour = v.getHours(), m.et.minute = v.getMinutes()), m.et.p = 60 * m.et.hour + m.et.minute, d.push(m)
                    }
                } else {
                    var m;
                    (m = {}).event = e[h], m.day = u.getDate(), m.year = u.getFullYear(), m.month = u.getMonth() + 1, "" == option.rowsList || option.dayWithTime && "day" == option.view ? m.allday = 1 == e[h][4] : m.allday = 1, m.crossday = 1 == e[h][5], m.reevent = e[h][6], m.daystr = [m.year, m.month, m.day].join("/"), m.st = {}, m.st.hour = u.getHours(), m.st.minute = u.getMinutes(), m.st.p = 60 * m.st.hour + m.st.minute, m.et = {}, m.et.hour = v.getHours(), m.et.minute = v.getMinutes(), m.et.p = 60 * m.et.hour + m.et.minute, (m.allday || m.st.hour >= option.hoursStart && m.st.hour <= option.hoursEnd) && ("" == n || "" != n && ("dc_locations" == option.rowsByCategory && e[h][9] == n || "dc_subjects" == option.rowsByCategory && e[h][1] == n)) && d.push(m)
                }
            }
            for (var g = 0, f = 0; f < i; f++) {
                var y = t[f];
                l[f] = [], s[f] = [], y.daystr = y.year + "/" + y.month + "/" + y.day;
                for (h = 0; h < d.length; h++) d[h].crossday || d[h].allday ? (y.daystr == d[h].daystr || 0 == f && y.date >= d[h].event[2] && y.date <= d[h].event[3]) && (s[f].push(d[h]), g++) : y.daystr == d[h].daystr && l[f].push(d[h])
            }
            var w = t[i - 1].date;
            for (f = 0; f < i; f++) {
                if ((D = s[f]).length > 0)
                    for (h = 0; h < D.length; h++) {
                        var b = DateDiff("d", w, D[h].event[3]) > 0 ? w : D[h].event[3];
                        D[h].colSpan = 0;
                        for (var _ = t[f].date; _ <= b; _ = DateAdd("d", 1, _)) D[h].colSpan += __VIEWWEEKDAYS[_.getDay()]
                    }
                D = null
            }
            for (f = 0; f < i; f++) {
                var D;
                if ((D = l[f]).length > 0) {
                    _ = [];
                    var $ = [],
                        E = [],
                        M = D.length;
                    for (h = 0; h < M; ++h) {
                        for (var k = D[h], x = k.st.p, A = 0; $[A] > x;) A++;
                        for (k.PO = A, k.ne = [], $[A] = k.et.p || 1440, _[A] = k, E[A] || (E[A] = []), E[A].push(k), 0 != A && (k.pe = [_[A - 1]], _[A - 1].ne.push(k)), A += 1; $[A] <= x;) A++;
                        if (_[A]) {
                            var W = _[A];
                            k.ne.push(W), W.pe.push(k)
                        }
                        k.width = 1 / (k.PO + 1), k.left = 1 - k.width
                    }
                    W = Array.prototype.concat.apply([], E);
                    _ = $ = E = null;
                    var S = W.length;
                    for ($ = S; $--;) {
                        var O = 1;
                        for (x = 0, E = (_ = W[$]).ne.length; E--;) {
                            A = _.ne[E];
                            x = Math.max(x, A.VL), O = Math.min(O, A.left)
                        }
                        _.VL = x + 1, _.width = O / (_.PO + 1), _.left = O - _.width
                    }
                    for ($ = 0; $ < S; $++) {
                        if ((_ = W[$]).left = 0, _.pe)
                            for (E = _.pe.length; E--;) {
                                O = _.pe[E];
                                _.left = Math.max(_.left, O.left + O.width)
                            }
                        var I = (1 - _.left) / _.VL;
                        _.width = Math.max(_.width, I), _.aQ = Math.min(1 - _.left, _.width + .7 * I)
                    }
                    D = null, l[f] = W
                }
            }
            return g
        }

        function BuildWTHeader(t, e) {
            for (var a = 0; a < e.length; a++) {
                var o, n, i;
                1 == e.length ? (o = "", n = "", i = "") : (o = "", n = i18n.dcmvcal.to_date_view, i = "wk-daylink"), (1 == e.length || __VIEWWEEKDAYS[e[a].date.getDay()]) && t.push("<th abbr='", dateFormat.call(e[a].date, "M/d/yyyy"), "' class='gcweekname' scope=\"col\"><div title='", n, "' ", o, " class='wk-dayname'><span class='", i, "'>", e[a].display, "</span></div></th>")
            }
        }

        function BuildWTBodyDayWithCol(t, e, a, o, n, i) {
            if (t.push('<td colspan="' + option.columnsList.length + '" class="wk-allday"'), t.push('><div id="weekViewAllDaywk' + n.thecontainer + i + '"><table class="st-grid" height="100%" cellpadding="0" cellspacing="0" ><tbody>'), i = ' row="' + i + '"', 0 == o) {
                t.push('<tr class="wk-allday-last">');
                for (var r = 0; r < option.columnsList.length; r++) t.push('<td  class="st-c st-s"', " ch='qkadd' abbr='", dateFormat.call(e[0].date, "yyyy-M-d"), "' axis='00:00'>&nbsp;</td>");
                t.push("</tr>")
            } else {
                for (var d = a.length, s = 0, l = [], p = 0; p < d; p++) l.push(0);
                var c = new Array,
                    h = 0;
                for (p = 0; s < o && p < o; p++)
                    for (var u = 0; u < d;) {
                        for (var v = a[u][l[u]], m = 0; m < option.columnsList.length; m++)
                            if (v && ("dc_locations" == option.dayWithColumns && v.event[9] == option.columnsList[m] || "dc_subjects" == option.dayWithColumns && v.event[1] == option.columnsList[m])) {
                                l[u] = l[u] + 1;
                                var g = BuildMonthDayEvent(v, e[u].date, d - u);
                                c[m] || (c[m] = new Array), c[m][c[m].length] = "<td class='st-c' ch='show'>" + g + "</td>", c[m].length > h && (h = c[m].length), s++
                            } u++
                    }
                for (p = 0; p < h; p++) {
                    t.push("<tr>");
                    for (m = 0; m < option.columnsList.length; m++) c[m] && c[m][p] ? t.push(c[m][p]) : t.push("<td class='st-c' ch='show'>&nbsp;</td>");
                    t.push("<tr>")
                }
                t.push('<tr height="100%" class="wk-allday-last">');
                for (m = 0; m < option.columnsList.length; m++)
                    for (u = 0; u < d; u++) t.push("<td height=\"100%\" class='st-c st-s' ch='qkadd' abbr='", dateFormat.call(e[u].date, "M/d/yyyy"), "' axis='00:00'>&nbsp;</td>");
                t.push("</tr>")
            }
            t.push("</tbody></table></div></td></tr>"), t.push("<tr>"), t.push('<td style="height: 5px;"'), e.length > 1 && ("week" == option.view ? t.push(" colSpan='", __VIEWWEEKDAYSTOTAL + 2, "'") : t.push(" colSpan='", option.nOfDays + 2, "'")), t.push("></td>"), t.push("</tr>")
        }

        function BuildWTBody(t, e, a, o, n, i) {
            var r = i;
            if (t.push('<td  class="wk-allday"'), e.length > 1 && ("week" == option.view ? t.push(" colSpan='", __VIEWWEEKDAYSTOTAL, "'") : t.push(" colSpan='", option.nOfDays, "'")), t.push('><div id="weekViewAllDaywk' + n.thecontainer + i + '"><table class="st-grid" height="100%" cellpadding="0" cellspacing="0" ><tbody>'), i = ' row="' + i + '"', 0 == o) {
                t.push('<tr class="wk-allday-last">');
                for (var d = 0; d < e.length; d++) 0 != __VIEWWEEKDAYS[d] && t.push('<td  class="st-c st-s"', " ch='qkadd' abbr='", dateFormat.call(e[d].date, "yyyy-M-d"), "' axis='00:00'>&nbsp;</td>");
                t.push("</tr>")
            } else {
                for (var s = a.length, l = 0, p = [], c = 0; c < s; c++) p.push(0);
                var h = new Array;
                for (c = 0; l < o && c < o; c++) {
                    t.push("<tr>");
                    for (var u = 0; u < s;) {
                        var v = a[u][p[u]],
                            m = u;
                        if (0 != __VIEWWEEKDAYS[e[m].date.getDay() % option.nOfDays] && t.push("<td class='st-c"), !v || "" != option.rowsByCategory && ("dc_locations" != option.rowsByCategory || v.event[9] != option.rowsList[r] || -1 != $.inArray(v.event[0], h) && "" == v.event[6]) && ("dc_subjects" != option.rowsByCategory || v.event[1] != option.rowsList[r] || -1 != $.inArray(v.event[0], h) && "" == v.event[6])) 0 != __VIEWWEEKDAYS[e[m].date.getDay() % option.nOfDays] && t.push(" st-s' ch='qkadd' abbr='", dateFormat.call(e[u].date, "M/d/yyyy"), "' axis='00:00'>&nbsp;"), u++;
                        else {
                            h[h.length] = v.event[0], p[u] = p[u] + 1, 0 != __VIEWWEEKDAYS[e[m].date.getDay() % option.nOfDays] && t.push("'");
                            var g = BuildMonthDayEvent(v, e[u].date, s - u);
                            if ("" != i && (g = g.replace('class="rb-o', i + ' class="rb-o')), v.colSpan > 1) {
                                0 != __VIEWWEEKDAYS[e[m].date.getDay() % option.nOfDays] && t.push(" colSpan='", v.colSpan, "'");
                                for (var f = 0, y = 0; y < v.colSpan && u + f < option.nOfDays;) y += __VIEWWEEKDAYS[e[u + f].date.getDay()], f++;
                                u += f
                            } else u++;
                            0 != __VIEWWEEKDAYS[e[m].date.getDay() % option.nOfDays] && t.push(" ch='show'>", g), g = null, l++
                        }
                        0 != __VIEWWEEKDAYS[e[m].date.getDay() % option.nOfDays] && t.push("</td>")
                    }
                    t.push("</tr>")
                }
                t.push('<tr height="100%" class="wk-allday-last">');
                for (u = 0; u < s; u++) 0 != __VIEWWEEKDAYS[e[u].date.getDay() % option.nOfDays] && t.push("<td height=\"100%\" class='st-c st-s' ch='qkadd' abbr='", dateFormat.call(e[u].date, "M/d/yyyy"), "' axis='00:00'>&nbsp;</td>");
                t.push("</tr>")
            }
            t.push("</tbody></table></div></td></tr>"), t.push("<tr>"), t.push('<td style="height: 5px;"'), e.length > 1 && ("week" == option.view ? t.push(" colSpan='", __VIEWWEEKDAYSTOTAL + 2, "'") : t.push(" colSpan='", option.nOfDays + 2, "'")), t.push("></td>"), t.push("</tr>")
        }

        function BuildDayScollEventheader(t, e, a, o) {
            t.push("<tr>"), t.push("<td style='width:" + option.hourswidth + "px;'></td>"), t.push("<td"), e.length > 1 ? "week" == option.view ? t.push(" colSpan='", __VIEWWEEKDAYSTOTAL, "'") : t.push(" colSpan='", option.nOfDays, "'") : "" != option.columnsList && "day" == option.view && t.push(" colSpan='", option.columnsList.length, "'"), t.push(' ><div id="tgspanningwrapper' + o.thecontainer + '" class="tg-spanningwrapper"><div style="font-size: 20px" class="tg-hourmarkers">');
            for (var n = option.cellheight / 2, i = option.hoursStart; i <= option.hoursEnd; i++) t.push('<div class="tg-dualmarker"style="height:' + (option.cellheight - n) + "px;line-height:" + (option.cellheight - n) + "px;margin-bottom:" + n + 'px"></div>');
            t.push("</div></div></td></tr>"), t.push("<tr>"), t.push('<td style="width: ' + option.hourswidth + 'px" class="tg-times">');
            var r = new Date,
                d = gP(r.getHours(), r.getMinutes()) - 4;
            t.push('<div id="tgnowptr' + o.thecontainer + '" class="tg-nowptr" style="left:0px;top:', d, 'px"></div>');
            var s = "";
            for (i = option.hoursStart; i <= option.hoursEnd; i++) s = fomartTimeAMPM(i, 0, __MilitaryTime), t.push('<div style="height: ' + option.cellheight + 'px" class="tg-time">', s, "</div>");
            t.push("</td>")
        }

        function BuildDayScollEventbody(t, e, a, o) {
            for (var n = new Date, i = gP(n.getHours(), n.getMinutes()) - 4, r = e.length, d = 0; d < r; d++)
                if (0 != __VIEWWEEKDAYS[e[d].date.getDay()]) {
                    t.push("<td class=\"tg-col\" ch='qkadd' abbr='", dateFormat.call(e[d].date, "M/d/yyyy"), "'>");
                    var s = dateFormat.call(e[d].date, "yyyyMMdd") == dateFormat.call(new Date, "yyyyMMdd");
                    if (s && t.push('<div style="margin-bottom: -' + (option.hoursEnd - option.hoursStart + 1) * option.cellheight + "px; height:" + (option.hoursEnd - option.hoursStart + 1) * option.cellheight + 'px" class="tg-today"></div>'), t.push('<div  style="margin-bottom: -' + (option.hoursEnd - option.hoursStart + 1) * option.cellheight + "px; height: " + (option.hoursEnd - option.hoursStart + 1) * option.cellheight + "px\" id='tgCol" + o.thecontainer, d, '\' class="tg-col-eventwrapper">'), BuildEvents(t, a[d], e[d]), t.push("</div>"), t.push('<div class="tg-col-overlaywrapper" id=\'tgOver' + o.thecontainer, d, "'>"), s) {
                        var l = i + 4;
                        t.push('<div id="tgnowmarker' + o.thecontainer + '" class="tg-hourmarker tg-nowmarker" style="left:0px;top:', l, 'px"></div>')
                    }
                    t.push("</div>"), t.push("</td>")
                } t.push("</tr>")
        }

        function BuildDayScollEventbodyWithCol(t, e, a, o) {
            for (var n = new Date, i = gP(n.getHours(), n.getMinutes()) - 4, r = (e.length, 0); r < option.columnsList.length; r++) {
                t.push("<td class=\"tg-col\" ch='qkadd' col='" + option.columnsList[r] + "' abbr='", dateFormat.call(e[0].date, "M/d/yyyy"), "'>");
                var d = dateFormat.call(e[0].date, "yyyyMMdd") == dateFormat.call(new Date, "yyyyMMdd");
                d && t.push('<div style="margin-bottom: -' + (option.hoursEnd - option.hoursStart + 1) * option.cellheight + "px; height:" + (option.hoursEnd - option.hoursStart + 1) * option.cellheight + 'px" class="tg-today"></div>'), t.push('<div  style="margin-bottom: -' + (option.hoursEnd - option.hoursStart + 1) * option.cellheight + "px; height: " + (option.hoursEnd - option.hoursStart + 1) * option.cellheight + "px\" id='tgCol" + o.thecontainer, 0, '\' class="tg-col-eventwrapper">');
                for (var s = new Array, l = 0; l < a[0].length; l++) {
                    var p = a[0][l];
                    p.left = 0, p.aQ = 1, ("dc_locations" == option.dayWithColumns && p.event[9] == option.columnsList[r] || "dc_subjects" == option.dayWithColumns && p.event[1] == option.columnsList[r]) && (s[s.length] = p)
                }
                if (BuildEvents(t, s, e[0]), t.push("</div>"), t.push('<div class="tg-col-overlaywrapper" id=\'tgOver' + o.thecontainer, 0, "'>"), d) {
                    var c = i + 4;
                    t.push('<div id="tgnowmarker' + o.thecontainer + '" class="tg-hourmarker tg-nowmarker" style="left:0px;top:', c, 'px"></div>')
                }
                t.push("</div>"), t.push("</td>")
            }
            t.push("</tr>")
        }

        function BuildEvents(t, e, a) {
            for (var o = 0; o < e.length; o++) {
                var n = BuildDayEvent(tc(e[o].event[7]), e[o], o);
                t.push(n)
            }
        }

        function getTitle(t) {
            var e, a, o, n, i = 1 != t[4];
            n = t[1];
            var r = getymformat(t[2], null, i, !0),
                d = getymformat(t[3], t[2], i, !0);
            e = dateFormat.call(t[2], r) + " - " + dateFormat.call(t[3], d), a = null != t[9] && "" != t[9] ? ($.tzfdbrowser.mozilla ? "" : "\r\n") + i18n.dcmvcal.location + ":" + t[9] : "", o = null != t[10] && "" != t[10] ? t[10] : "";
            var s = [];
            return 1 == t[4] ? s.push("[" + i18n.dcmvcal.allday_event + "]", $.tzfdbrowser.mozilla ? "" : "\r\n") : 1 == t[5] && s.push("[" + i18n.dcmvcal.repeat_event + "]", $.tzfdbrowser.mozilla ? "" : "\r\n"), s.push(i18n.dcmvcal.time + ":", e, $.tzfdbrowser.mozilla ? "" : "\r\n", i18n.dcmvcal.event + ":", n, a), "" != o && s.push($.tzfdbrowser.mozilla ? "" : "\r\n", i18n.dcmvcal.participant + ":", o), htmlE(s.join(""))
        }

        function htmlE(t) {
            return t = (t = $("<div/>").text(t).html()).replace(/&/g, "&amp;").replace(/"/g, "&quot;")
        }

        function BuildDayEvent(t, e, a) {
            var o = {
                bdcolor: t[0],
                bgcolor2: t[0],
                bgcolor1: t[2],
                width: "70%",
                icon: "",
                title: "",
                data: ""
            };
            e.noStarttime ? o.starttime = "" : o.starttime = fomartTimeAMPM(e.st.hour, e.st.minute, __MilitaryTime), e.noResizer ? o.endtime = "" : o.endtime = fomartTimeAMPM(e.et.hour, e.et.minute, __MilitaryTime), o.content = e.event[1], o.title = getTitle(e.event), o.data = e.event.join("$*$");
            var n = [];
            n.push('<I class="cic cic-tmr">&nbsp;</I>'), e.reevent && n.push('<I class="cic cic-spcl">&nbsp;</I>'), o.icon = n.join("");
            var i = gP(e.st.hour, e.st.minute),
                r = gP(e.et.hour, e.et.minute);
            o.top = i + "px", o.left = 100 * e.left + "%", o.width = 100 * e.aQ + "%", o.height = 0 == r && i > 0 ? i - 4 : r - i - 4, o.i = a, option.enableDrag && 1 != option.readonly && (option.userEdit || option.userOwner == e.event[12] && option.userEditOwner) && 1 == e.event[8] && !e.noResizer ? (o.drag = "drag", o.redisplay = "block") : (o.drag = "", o.redisplay = "none"), o.userEdition = option.userOwner == e.event[12] && (option.userEditOwner || option.userDelOwner) ? "uEdition" : "", o.location = null != e.event[9] ? e.event[9] : "", o.description = null != e.event[11] ? e.event[11] : "";
            var d = Tp(__SCOLLEVENTTEMP, o);
            return o = null, d
        }

        function GetMonthViewBodyHeight() {
            return option.height
        }

        function GetMonthViewHeaderHeight() {
            return 26
        }

        function BuilderMonthBody(t, e, a, o, n, i) {
            var r = new Date(e.getFullYear(), e.getMonth(), 1),
                d = a - r.getDay(),
                s = e.getMonth();
            d > 0 && (d -= 7);
            var l = DateAdd("d", d, r),
                p = DateAdd("d", 34, l),
                c = 5;
            p.getFullYear() == e.getFullYear() && p.getMonth() == e.getMonth() && p.getDate() < __MonthDays[s] && (p = DateAdd("d", 7, p), c = 6), option.vstart = l, option.vend = p;
            var h = DateAdd("d", 15, l);
            option.datestrshow = __MonthNameLarge[h.getMonth()] + " " + h.getFullYear();
            var u = (n -= 18 * c) / c,
                v = parseInt(u / (option.cellheight / 2));
            u % (option.cellheight / 2) > 15 && v++, 0 == v && v++;
            for (var m = 100 / c, g = [], f = formartEventsInHashtable(o, a, 7, l, p), y = [], w = [], _ = 0; _ < c; _++) {
                var D = 0;
                g[_] = b = [];
                for (var $ = 0; $ < 7; $++) {
                    var E = DateAdd("d", 7 * _ + $, l);
                    w[7 * _ + $] = E;
                    var M = dateFormat.call(E, "MMddyyyy");
                    b[$] = f[M], b[$] && b[$].length > 0 && (D += b[$].length)
                }
                y[_] = D
            }
            eventDiv.data("mvdata", g);
            for (_ = 0; _ < c; _++) {
                t.push("<div id='mvrow" + i.thecontainer + "_", _, "' style=\"HEIGHT:", m, "%; TOP:", m * _, '%"  class="month-row">'), t.push('<table class="st-bg-table" cellSpacing="0" cellPadding="0"><tbody><tr>');
                var k = y[_],
                    x = i.weekstartday;
                for ($ = 0; $ < 7; x++, $++) {
                    x > 6 && (x = 0);
                    var A = w[7 * _ + $];
                    0 != __VIEWWEEKDAYS[x] && (t.push('<td display="' + __VIEWWEEKDAYS[x] + "\" abbr='", dateFormat.call(A, "M/d/yyyy"), "' ch='qkadd' axis='00:00' title=''"), dateFormat.call(A, "yyyyMMdd") == dateFormat.call(new Date, "yyyyMMdd") ? t.push(' class="st-bg st-bg-today">') : t.push(' class="st-bg">'), t.push("&nbsp;</td>"))
                }
                t.push("</tr></tbody></table>"), t.push('<table class="st-grid" cellpadding="0" cellspacing="0"><tbody>'), t.push("<tr>");
                for ($ = 0; $ < 7; $++) {
                    var W = {
                        titleClass: "",
                        dayshow: "",
                        display: __VIEWWEEKDAYS[(a + $) % 7] + "i" + $
                    };
                    A = w[7 * _ + $];
                    dateFormat.call(A, "yyyyMMdd") == dateFormat.call(new Date, "yyyyMMdd") && (W.titleClass = " st-dtitle-today"), A.getMonth() != s && (W.titleClass = " st-dtitle-nonmonth"), W.title = dateFormat.call(A, i18n.dcmvcal.dateformat.fulldayshow), 1 == A.getDate() ? 0 == A.getMonth ? W.dayshow = dateFormat.call(A, i18n.dcmvcal.dateformat.fulldayshow) : W.dayshow = dateFormat.call(A, i18n.dcmvcal.dateformat.Md3) : W.dayshow = A.getDate(), W.abbr = dateFormat.call(A, "M/d/yyyy"), 0 != __VIEWWEEKDAYS[(a + $) % 7] && t.push(Tp("<td display=\"${display}\" class=\"st-dtitle${titleClass}\" ch='qkadd' abbr='${abbr}' axis='00:00' title=\"${title}\"><span class='monthdayshow'>${dayshow}</span></a></td>", W))
                }
                t.push("</tr>");
                var S = w[7 * _];
                BuildMonthRow(t, g[_], k, v, S, a), t.push("</tbody></table>"), t.push("</div>")
            }
            g = y = w = f = null
        }

        function formartEventsInHashtable(t, e, a, o, n) {
            for (var i = new Object, r = t.length, d = 0; d < r; d++) {
                var s = t[d][2],
                    l = t[d][3],
                    p = DateDiff("d", s, l),
                    c = {};
                if (c.event = t[d], c.day = s.getDate(), c.year = s.getFullYear(), c.month = s.getMonth() + 1, c.allday = 1 == t[d][4], c.crossday = 1 == t[d][5], c.reevent = t[d][6], c.daystr = c.year + "/" + c.month + "/" + c.day, c.st = {}, c.st.hour = s.getHours(), c.st.minute = s.getMinutes(), c.st.p = 60 * c.st.hour + c.st.minute, c.et = {}, c.et.hour = l.getHours(), c.et.minute = l.getMinutes(), c.et.p = 60 * c.et.hour + c.et.minute, p > 0) {
                    s < o && (s = o), l > n && (l = n);
                    var h = e - s.getDay();
                    h > 0 && (h -= a), s = new Date(s.getFullYear(), s.getMonth(), s.getDate());
                    for (var u = DateAdd("d", h, s); u <= l; s = u = DateAdd("d", a, u)) {
                        for (var v = Clone(c); !__VIEWWEEKDAYS[s.getDay()] && u <= l;) s = DateAdd("d", 1, s);
                        var m = dateFormat.call(s, "MMddyyyy"),
                            g = DateDiff("d", u, l),
                            f = DateDiff("d", u, s);
                        if (null == i[m] && (i[m] = []), g >= a)
                            if (0 == f) v.colSpan = __VIEWWEEKDAYSTOTAL;
                            else {
                                var y = DateAdd("d", a, u);
                                v.colSpan = 0;
                                for (g = s; g < y; g = DateAdd("d", 1, g)) v.colSpan += __VIEWWEEKDAYS[g.getDay()]
                            }
                        else {
                            v.colSpan = 0;
                            for (g = s; g <= l; g = DateAdd("d", 1, g)) v.colSpan += __VIEWWEEKDAYS[g.getDay()]
                        }
                        v.colSpan > 0 && i[m].push(v), v = null
                    }
                } else {
                    null == i[m = dateFormat.call(t[d][2], "MMddyyyy")] && (i[m] = []), c.colSpan = 1, i[m].push(c)
                }
                c = null
            }
            return i
        }

        function BuildMonthRow(t, e, a, o, n, i) {
            var r = [],
                d = [],
                s = [],
                l = [],
                p = __VIEWWEEKDAYS.slice(0);
            if (__VIEWWEEKDAYSTOTAL != e.length) {
                var c = (p = __VIEWWEEKDAYS.slice(0)).splice(0, i);
                p = p.concat(c);
                for (var h = 6; h >= 0; h--) 0 == p[h] && e.splice(h, 1)
            }
            var u = e.length,
                v = 0;
            for (h = 0; h < u; h++) e[h] && v < e[h].length && (v = e[h].length);
            o = v + 1;
            var m = 0;
            for (h = 0; h < 7; h++) 0 != p[h] && (r.push(0), d.push(0), s.push(0), l.push(DateAdd("d", h, n)));
            for (var g = 0; g < u; g++) {
                var f = e[g] ? e[g].length : 0;
                d[g] += f;
                for (var y = 0; y < f; y++) {
                    if ((E = e[g][y]) && E.colSpan > 1)
                        for (var w = 1; w < E.colSpan; w++) d[g + w]++
                }
            }
            var b = "<td class='${cssclass}' display='${display}' axis='${axis}' ch='${ch}' abbr='${abbr}' title='${title}' ${otherAttr}>${html}</td>",
                _ = 0;
            for (g = 0; g < o && m < a; g++) {
                t.push("<tr class='mv_month_row' maxEventsRow='" + v + "'>");
                for (var D = 0; D < u;) {
                    var E, M = 0,
                        k = {
                            class: "",
                            axis: "",
                            ch: "",
                            title: "",
                            abbr: "",
                            html: "",
                            otherAttr: "",
                        },
                        x = ["st-c"];
                    if (E = e[D] ? e[D][r[D]] : void 0) {
                        r[D] = r[D] + 1;
                        var A = !1;
                        if (s[D] + 1 == d[D] && 1 == E.colSpan && (A = !0), !A && g == o - 1 && s[D] < d[D]) m++, $.extend(k, {
                            axis: D,
                            ch: "more",
                            abbr: dateFormat.call(l[D], "M/d/yyyy"),
                            html: i18n.dcmvcal.others + " " + (d[D] - s[D]) + i18n.dcmvcal.item
                        }), x.push("st-more st-moreul"), D++;
                        else {
                            if (k.html = BuildMonthDayEvent(E, l[D], u - D), k.ch = "show", E.colSpan > 1) {
                                k.otherAttr = " colSpan='" + E.colSpan + "'";
                                for (w = 0; w < E.colSpan; w++) s[D + w] = s[D + w] + 1;
                                for (var W = 0, S = 0; S < E.colSpan;) S += __VIEWWEEKDAYS[l[D + W].getDay()], W++;
                                D += W
                            } else s[D] = s[D] + 1, D++;
                            m++
                        }
                    } else g == o - 1 && s[D] < d[D] && d[D] > 0 ? ($.extend(k, {
                        axis: D,
                        ch: "more",
                        abbr: dateFormat.call(l[D], "M/d/yyyy"),
                        html: i18n.dcmvcal.others + " " + (d[D] - s[D]) + i18n.dcmvcal.item
                    }), x.push("st-more st-moreul"), D++) : (M = 1, $.extend(k, {
                        html: "&nbsp;",
                        ch: "qkadd",
                        display: 1,
                        axis: "00:00",
                        abbr: dateFormat.call(l[D], "M/d/yyyy"),
                        title: ""
                    }), x.push("st-s"), _ = D, D++);
                    k.cssclass = x.join(" "), x = null, (0 == M || 0 != __VIEWWEEKDAYS[l[_].getDay() % 7]) && t.push(Tp(b, k)), k = null
                }
                t.push("</tr>")
            }
            r = d = s = l = null
        }

        function BuildMonthDayEvent(t, e, a) {
            var o = {
                color: tc(t.event[7])[2],
                title: "",
                extendClass: "",
                extendHTML: "",
                data: ""
            };
            o.title = getTitle(t.event), o.id = "bbit_cal_event_" + t.event[0], option.enableDrag && 1 != option.readonly && (option.userEdit || option.userOwner == t.event[12] && option.userEditOwner) && 1 == t.event[8] ? o.eclass = "drag" : o.eclass = "cal_" + t.event[0], o.data = t.event.join("$*$");
            var n, i = [],
                r = t.event[2] < e,
                d = DateDiff("d", e, t.event[3]) >= a;
            (r || d) && (r && (i.push('<div class="st-ad-ml"></div>'), o.extendClass = "st-ad-mpad "), d && i.push('<div class="st-ad-mr"></div>'), o.extendHTML = i.join("")), n = t.allday || r ? t.event[1] : '<span class="t-time">' + fomartTimeAMPM(t.st.hour, t.st.minute, __MilitaryTime) + "</span> " + t.event[1];
            var s = [];
            return s.push(Tp('<span style="cursor: pointer">${content}</span>', {
                content: n
            })), s.push('<I class="cic cic-tmr">&nbsp;</I>'), t.reevent && s.push('<I class="cic cic-rcr">&nbsp;</I>'), o.content = s.join(""), o.location = null != t.event[9] ? t.event[9] : "", o.description = null != t.event[11] ? t.event[11] : "", o.userEdition = option.userOwner == t.event[12] && (option.userEditOwner || option.userDelOwner) ? "uEdition" : "", Tp(__ALLDAYEVENTTEMP, o)
        }

        function populate() {
            if (option.isloading) return !0;
            if (option.url && "" != option.url) {
                option.isloading = !0, option.onBeforeRequestData && $.isFunction(option.onBeforeRequestData) && option.onBeforeRequestData(1);
                var t = (new Date).getTimezoneOffset() / 60 * -1,
                    e = [{
                        name: "showdate",
                        value: dateFormat.call(option.showday, "M/d/yyyy HH:mm")
                    }, {
                        name: "startdate",
                        value: dateFormat.call(option.vstart, "M/d/yyyy HH:mm")
                    }, {
                        name: "enddate",
                        value: dateFormat.call(option.vend, "M/d/yyyy HH:mm")
                    }, {
                        name: "viewtype",
                        value: option.view
                    }, {
                        name: "list_start",
                        value: option.list_start
                    }, {
                        name: "list_end",
                        value: option.list_end
                    }, {
                        name: "list_eventsPerPage",
                        value: option.list_eventsPerPage
                    }, {
                        name: "lastdate",
                        value: "" == option.lastdate ? "" : dateFormat.call(option.lastdate, "M/d/yyyy HH:mm")
                    }, {
                        name: "list_order",
                        value: option.list_order
                    }, {
                        name: "timezone",
                        value: t
                    }];
                if (option.extParam)
                    for (var a = 0; a < option.extParam.length; a++) e[e.length] = option.extParam[a];
                $.ajax({
                    type: option.method,
                    url: option.url,
                    data: e,
                    dataType: "json",
                    dataFilter: function(t, e) {
                        return t
                    },
                    success: function(t) {
                        if (null != t && null != t.error) option.onRequestDataError && option.onRequestDataError(1, t);
                        else try {
                            if ($.each(t.events, (function(t, e) {
                                    e[2] = parseDate(e[2]), e[3] = parseDate(e[3])
                                })), "list" != option.view) t.start = parseDate(t.start), t.end = parseDate(t.end);
                            else
                                for (var e = new Date, a = 0; a < t.events.length; a++) t.events[a][2] < e && (t.events.splice(a, 1), a--);
                            "list" == option.view && "" == option.lastdate && "desc" == option.list_order && "" != t.end && (option.lastdate = parseDate(t.end)), "list" == option.view && "" == option.lastdate && "asc" == option.list_order && "" != t.start && (option.lastdate = parseDate(t.start)), responseData(t, t.start, t.end), "list" != option.view && pushER(t.start, t.end)
                        } catch (t) {}
                        option.onAfterRequestData && $.isFunction(option.onAfterRequestData) && option.onAfterRequestData(1), option.isloading = !1
                    },
                    error: function(t) {
                        try {
                            option.onRequestDataError ? option.onRequestDataError(1, t) : alert(i18n.dcmvcal.get_data_exception), option.onAfterRequestData && $.isFunction(option.onAfterRequestData) && option.onAfterRequestData(1), option.isloading = !1
                        } catch (t) {}
                    }
                })
            } else alert("url" + i18n.dcmvcal.i_undefined)
        }

        function responseData(t, e, a) {
            for (var o, n, i, r, d = new Array, s = new Array, l = 0; l < t.events.length; l++)
                if (excludeEvents = new Array, "" != (n = t.events[l])[6] && null != n[6] && null != n[6])
                    if ((n[6] + "").match(/^\d+$/)) s["uid" + n[6]] || (s["uid" + n[6]] = new Array), s["uid" + n[6]][s["uid" + n[6]].length] = new Date(n[2].getFullYear(), n[2].getMonth(), n[2].getDate()).toString(), d[d.length] = n.slice(0);
                    else {
                        if (/;exdate=/i.test(n[6])) {
                            var p = n[6].split(";exdate=,");
                            n[6] = p[0];
                            for (var c = p[1].split(","), h = 0; h < c.length; h++) {
                                var u = c[h].split("/"),
                                    v = new Date(u[2], u[0] - 1, u[1]);
                                excludeEvents[excludeEvents.length] = v.toString()
                            }
                        }
                        try {
                            var m = RRule.parseString(n[6]);
                            m.dtstart = n[2];
                            var g = new RRule(m),
                                f = n[3] - n[2];
                            if ("list" == option.view)
                                if ("desc" == option.list_order) {
                                    i = g.between(parseDate(e), option.lastdate);
                                    for (h = 0; h <= option.list_eventsPerPage; h++) {
                                        null != (y = g.before(i[i.length - 1], !1)) && ("" == e || parseDate(e) <= y) && ("" == a || parseDate(a) >= y) && (i[i.length] = y)
                                    }
                                } else {
                                    i = "" != option.lastdate ? g.between(option.lastdate, "" != a && parseDate(a), !0) : "" != e ? g.between(parseDate(e), "" != a && parseDate(a), !0) : g.between(n[2], "" != a && parseDate(a), !0);
                                    for (h = 0; h <= option.list_eventsPerPage; h++) {
                                        var y;
                                        null != (y = g.after(i[i.length - 1], !1)) && ("" == e || parseDate(e) <= y) && ("" == a || parseDate(a) >= y) && (i[i.length] = y)
                                    }
                                }
                            else i = g.between(DateAdd("d", -1, e), DateAdd("d", 1, a));
                            s["uid" + n[0]] && (excludeEvents = $.merge(excludeEvents, s["uid" + n[0]]));
                            for (h = 0; h < i.length; h++) {
                                var w = new Date(i[h].getFullYear(), i[h].getMonth(), i[h].getDate()); - 1 == $.inArray(w.toString(), excludeEvents) && (i[h] = new Date(i[h].getFullYear(), i[h].getMonth(), i[h].getDate(), n[2].getHours(), n[2].getMinutes()), (r = n.slice(0))[2] = i[h], r[3] = DateAdd("l", f, i[h]), d[d.length] = r)
                            }
                        } catch (t) {}
                    }
            else d[d.length] = n.slice(0);
            t.events = d, o = t.events && t.events.length > 0 ? "list" == option.view && "desc" == option.list_order ? t.events.sort((function(t, e) {
                return t[2].toString() == e[2].toString() ? t[0] > e[0] ? -1 : 1 : t[2] > e[2] ? -1 : 1
            })) : t.events.sort((function(t, e) {
                return t[2].toString() == e[2].toString() ? t[0] > e[0] ? 1 : -1 : t[2] > e[2] ? 1 : -1
            })) : [], "list" == option.view && (option.eventItems = []), ConcatEvents(o, e, a), render()
        }

        function clearrepeat(t, e, a) {
            var o = t.length;
            if (o > 0)
                for (var n = t[0][2], i = t[o - 1][2], r = 0, d = option.eventItems.length; r < d && !(option.eventItems[r][2] > i || 0 == o); r++)
                    if (option.eventItems[r][2] >= n)
                        for (var s = 0; s < o; s++)
                            if (option.eventItems[r][0] == t[s][0] && option.eventItems[r][2].toString() == t[s][2].toString() && (option.eventItems[r][2] < e || option.eventItems[r][2] > a)) {
                                t.splice(s, 1), o--;
                                break
                            }
        }

        function ConcatEvents(t, e, a) {
            if (t || (t = []), t)
                if (0 == option.eventItems.length) option.eventItems = t;
                else {
                    clearrepeat(t, e, a);
                    t.length;
                    var o = option.eventItems.length,
                        n = -1,
                        i = o,
                        r = e,
                        d = a;
                    if (option.eventItems[0][2] > d) return void(option.eventItems = t.concat(option.eventItems));
                    if (option.eventItems[o - 1][2] < r) return void(option.eventItems = option.eventItems.concat(t));
                    for (var s = 0; s < o; s++)
                        if (option.eventItems[s][2] >= r && n < 0) n = s;
                        else if (option.eventItems[s][2] > d) {
                        i = s;
                        break
                    }
                    var l = n <= 0 ? [] : option.eventItems.slice(0, n),
                        p = i == o ? [] : option.eventItems.slice(i);
                    option.eventItems = [].concat(l, t, p), t = l = p = null
                }
        }

        function weekormonthtoday(t) {
            $("#show" + option.view + "btn" + option.thecontainer).removeClass("ui-state-active");
            var e = $(this).attr("abbr");
            option.showday = str_MdyyyyHHmm_todate(e + " 00:00"), option.view = "day", $("#show" + option.view + "btn" + option.thecontainer).addClass("ui-state-active"), render(), option.onweekormonthtoday && option.onweekormonthtoday(option), t.stopPropagation()
        }

        function move_mv_dlg() {
            $(".mv_dlg").css("top", parseFloat($(".mv_dlg").css("top")) + 17), $(".mv_dlg").css("left", parseFloat($(".mv_dlg").css("left")) - 29), $(".mv_dlg").css("height", "0px")
        }

        function parseDate(t) {
            var e = t.split(" "),
                a = e[0].split("/"),
                o = e[1].split(":");
            return 2 != o.length && (o = new Array(0, 0)), new Date(1 * a[2], 1 * a[0] - 1, 1 * a[1], 1 * o[0], 1 * o[1])
        }

        function gP(t, e) {
            return t > option.hoursEnd ? (option.hoursEnd - option.hoursStart + 1) * option.cellheight : (t - option.hoursStart) * option.cellheight + parseInt(e / 60 * option.cellheight)
        }

        function gW(t, e) {
            t >= e && (e = t + option.cellheight / 2);
            var a = t / option.cellheight,
                o = parseInt(a) + option.hoursStart,
                n = a - o + option.hoursStart >= .5 ? 30 : 0,
                i = e / option.cellheight,
                r = parseInt(i) + option.hoursStart,
                d = i - r + option.hoursStart >= .5 ? 30 : 0;
            return r > 23 && (r = 23, d = 30), o == r && n == d && (0 == n ? d = 30 : (r++, d = 0)), {
                sh: o,
                sm: n,
                eh: r,
                em: d,
                h: e - t
            }
        }

        function gH(t, e, a) {
            var o = Math.min(t, e),
                n = Math.max(t, e),
                i = (o - a) / option.cellheight,
                r = parseInt(i) + option.hoursStart,
                d = i - r + option.hoursStart >= .5 ? 30 : 0,
                s = (n - a) / option.cellheight,
                l = parseInt(s) + option.hoursStart;
            return {
                sh: r,
                sm: d,
                eh: l,
                em: s - l + option.hoursStart >= .5 ? 30 : 0,
                h: n - o
            }
        }

        function pZero(t) {
            return t < 10 ? "0" + t : "" + t
        }

        function tc(t) {
            null != t && null != t || option.theme;
            return "" == (t = null != t && null != t && -1 != t ? t : option.theme) && (t = option.theme), [t, t, t, t]
        }

        function Tp(t, e) {
            return t.replace(/\$\{([\w]+)\}/g, (function(t, a) {
                var o = e[a];
                return void 0 !== o ? o : t
            }))
        }

        function Ta(t, e) {
            return t.replace(/\{([\d])\}/g, (function(t, a) {
                var o = e[a];
                return void 0 !== o ? encodeURIComponent(o) : ""
            }))
        }

        function fomartTimeShow(t) {
            var e = t % 12 < 10 && 12 != t ? "0" + t % 12 + ":00" : (12 == t ? "12" : t % 12) + ":00";
            return e += " " + (t >= 12 ? "pm" : "am")
        }

        function getymformat(t, e, a, o, n) {
            var i = null == a || t.getFullYear() != (new Date).getFullYear(),
                r = !0,
                d = !0,
                s = a || !1,
                l = o || !1;
            e && (i = e.getFullYear() != t.getFullYear(), e.getFullYear() == t.getFullYear() && t.getMonth() == e.getMonth() && t.getDate() == e.getDate() && (i = r = d = l = !1));
            var p = [];
            return i ? p.push(i18n.dcmvcal.dateformat.fulldayshow) : r ? p.push(i18n.dcmvcal.dateformat.Md3) : d && p.push(i18n.dcmvcal.dateformat.day), p.push(l ? " (W)" : "", s ? " HH:mm" : ""), p.join("")
        }

        function CalDateShow(t, e, a, o) {
            if (e) {
                var n = dateFormat.call(t, getymformat(t, null, a, o)),
                    i = dateFormat.call(e, getymformat(e, t, a, o));
                return [n, i].join("" != i ? " - " : "")
            }
            return dateFormat.call(t, getymformat(t, null, a))
        }

        function dochange() {
            var t = getRdate();
            checkInEr(t.start, t.end);
            populate()
        }

        function checkInEr(t, e) {
            var a = option.loadDateR.length;
            if (0 == a) return !1;
            for (var o = !1, n = !1, i = 0; i < a; i++) {
                o = !1, n = !1;
                var r = option.loadDateR[i];
                if (t >= r.startdate && t <= r.enddate && (o = !0), dateFormat.call(t, "yyyyMMdd") != dateFormat.call(r.startdate, "yyyyMMdd") && dateFormat.call(t, "yyyyMMdd") != dateFormat.call(r.enddate, "yyyyMMdd") || (o = !0), e ? (e >= r.startdate && e <= r.enddate && (n = !0), dateFormat.call(e, "yyyyMMdd") != dateFormat.call(r.startdate, "yyyyMMdd") && dateFormat.call(e, "yyyyMMdd") != dateFormat.call(r.enddate, "yyyyMMdd") || (n = !0)) : n = !0, o && n) break
            }
            return o && n
        }

        function buildtempdayevent(t, e, a, o, n, i, r, d, s) {
            var l = null != s && -1 != s && "" != s ? tc(s) : tc();
            return Tp(__SCOLLEVENTTEMP, {
                location: "",
                description: "",
                bdcolor: l[0],
                bgcolor2: l[0],
                bgcolor1: l[2],
                data: "",
                starttime: [pZero(t), pZero(e)].join(":"),
                endtime: [pZero(a), pZero(o)].join(":"),
                content: i || i18n.dcmvcal.new_event,
                title: i || i18n.dcmvcal.new_event,
                icon: '<I class="cic cic-tmr">&nbsp;</I>',
                top: "0px",
                left: "",
                width: r || "100%",
                height: n - 4,
                i: "-1",
                drag: "drag-chip",
                redisplay: d ? "block" : "none"
            })
        }

        function getdata(t) {
            var e = t.find("div.dhdV");
            return 1 == e.length ? parseED(e.html().split("$*$")) : null
        }

        function parseED(t) {
            if (t.length > 6) {
                var e = [];
                e.push(t[0], t[1], new Date(t[2]), new Date(t[3]), parseInt(t[4]), parseInt(t[5]), t[6], null != t[7] ? t[7] : -1, null != t[8] ? parseInt(t[8]) : 0);
                for (var a = 9; a < t.length; a++) e.push(t[a]);
                return e
            }
            return null
        }

        function quickd(t, e) {
            try {
                $("#bbit-cs-buddle").dialog("close")
            } catch (t) {}
            try {
                $(".mv_dlg_nmonth").dialog("close")
            } catch (t) {}
            var a = [{
                    name: "calendarId",
                    value: e
                }, {
                    name: "type",
                    value: t
                }],
                o = rebyKey(e, !0);
            option.onBeforeRequestData && option.onBeforeRequestData(3), $.post(option.quickDeleteUrl, a, (function(t) {
                t && (t.IsSuccess ? (o = null, populate(), option.onAfterRequestData && option.onAfterRequestData(3)) : (option.onRequestDataError && option.onRequestDataError(3, t), Ind(o), populate(), option.onAfterRequestData && option.onAfterRequestData(3)))
            }), "json"), populate()
        }

        function getbuddlepos(t, e) {
            var a = t - 110,
                o = e - 217,
                n = document.documentElement.clientWidth,
                i = document.documentElement.clientHeight,
                r = !1;
            return (a <= 0 || o <= 0 || a + 400 > n) && ((a = t - 200 <= 0 ? 10 : t - 200) + 400 >= n && (a = n - 410), (o = e - 159 <= 0 ? 10 : e - 159) + 164 >= i && (o = i - 165), r = !0), {
                left: a,
                top: o,
                hide: r
            }
        }

        function dayshow(t, e) {
            if (null == e && (e = getdata($(this))), null != e) {
                var a = '<div id="bbit-cs-buddle">' + e[1] + "<hr/>" + e[11] + "</div>";
                closeOpenDlg();
                var o = $("#bbit-cs-buddle");
                if (0 == o.length) {
                    (o = $(a).appendTo(document.body)).dialog({
                        width: option.dialogWidth,
                        resizable: !1,
                        modal: !1,
                        resizable: !1,
                        maxWidth: option.dialogWidth,
                        fluid: !0,
                        open: function(t, e) {
                            fluidDialog()
                        },
                        position: {
                            my: "left top",
                            at: "center bottom",
                            collision: "fit",
                            of: $(this)
                        }
                    }), dialogUnBlur(), $("#bbit-cs-buddle").parent().addClass("mv_dlg"), $('<div id="mv_corner" />').appendTo($(".mv_dlg .ui-dialog-titlebar")), move_mv_dlg();
                    $("#bbit-cs-delete"), $("#bbit-cs-editLink"), $("#bubbleClose2").click((function() {
                        try {
                            $("#bbit-cs-buddle").dialog("close")
                        } catch (t) {}
                    }));
                    if (option.showtooltipdwm_mouseover) {
                        (function() {
                            try {
                                return document.createEvent("TouchEvent"), !0
                            } catch (t) {
                                return !1
                            }
                        })() || $(document).one("click", (function() {
                            try {
                                $("#bbit-cs-buddle").dialog("close")
                            } catch (t) {}
                        }))
                    }
                }
            }
        }

        function dayshow1(t, e) {
            if (null == e && (e = getdata($(this))), null != e)
                if ("" != option.quickDeleteUrl && 1 == e[8] && (1 != option.readonly || 1 == option.readonly && option.showtooltipdwm || option.showtooltipdwm_mouseover)) {
                    var a = '<div id="bbit-cs-buddle"><div class="dialogdwm_event_content" style="border-left:3px solid ' + (e[7] && -1 != e[7] && null != e[7] ? e[7] : "#" + option.paletteDefault) + ';padding-left:5px"><div id="bbit-cs-buddle-timeshow" class="bubbletime"></div><div id="bbit-cs-title" class="bubbletitle"></div><div id="bbit-cs-location" class="bubblelocation"></div><div id="bbit-cs-description" class="bubbledescription"></div></div>';
                    1 != option.readonly && (option.userEdit || option.userDel || option.userOwner == e[12] && (option.userEditOwner || option.userDelOwner)) && (a += '<div class="bbit-cs-split"><input id="bbit-cs-id" type="hidden" value=""/>', (option.userDel || option.userOwner == e[12] && option.userDelOwner) && ("" != e[6] && null != e[6] && null != e[6] || (a += '[ <a id="bbit-cs-delete" class="lk">' + i18n.dcmvcal.i_delete + "</a> ]&nbsp;")), (option.userEdit || option.userOwner == e[12] && option.userEditOwner) && (a += ' <a id="bbit-cs-editLink" class="lk">' + i18n.dcmvcal.update_detail + " <StrONG>&gt;&gt;</StrONG></a>"), a += "</div>"), a += "</div>", closeOpenDlg();
                    var o = $("#bbit-cs-buddle");
                    if (0 == o.length) {
                        (o = $(a).appendTo(document.body)).dialog({
                            width: option.dialogWidth,
                            resizable: !1,
                            modal: !1,
                            resizable: !1,
                            maxWidth: option.dialogWidth,
                            fluid: !0,
                            open: function(t, e) {
                                fluidDialog()
                            },
                            position: {
                                my: "left top",
                                at: "center bottom",
                                collision: "fit",
                                of: $(this)
                            }
                        }), $("#bbit-cs-buddle").parent().addClass("mv_dlg"), $('<div id="mv_corner" />').appendTo($(".mv_dlg .ui-dialog-titlebar")), move_mv_dlg();
                        var n = $("#bbit-cs-delete"),
                            i = $("#bbit-cs-editLink");
                        $("#bubbleClose2").click((function() {
                            try {
                                $("#bbit-cs-buddle").dialog("close")
                            } catch (t) {}
                        }));
                        n.click((function() {
                            var t = $("#bbit-cs-buddle").data("cdata");
                            option.DeleteCmdhandler && $.isFunction(option.DeleteCmdhandler) && option.DeleteCmdhandler.call(this, t, quickd)
                        })), i.click((function(t) {
                            if (option.EditCmdhandler) {
                                if (option.EditCmdhandler && $.isFunction(option.EditCmdhandler)) {
                                    var e = $("#bbit-cs-buddle").data("cdata"),
                                        a = $("#bbit-cs-buddle").dialog("option", "position");
                                    $("#bbit-cs-buddle").remove(), option.EditCmdhandler.call(this, e, a)
                                }
                            } else alert("EditCmdhandler" + i18n.dcmvcal.i_undefined);
                            t.stopPropagation()
                        })), o.click((function(t) {
                            t.stopPropagation()
                        }))
                    }
                    var r = [],
                        d = 0 != DateDiff("d", e[2], e[3]);
                    r.push(dateFormat.call(e[2], i18n.dcmvcal.dateformat.fulldayshow)), 1 != e[4] && r.push(" ", fomartTimeAMPM(e[2].getHours(), e[2].getMinutes(), __MilitaryTime)), d ? (r.push(" - ", dateFormat.call(e[3], i18n.dcmvcal.dateformat.fulldayshow)), 1 != e[4] && r.push(" ", fomartTimeAMPM(e[3].getHours(), e[3].getMinutes(), __MilitaryTime))) : 1 != e[4] && r.push(" - ", fomartTimeAMPM(e[3].getHours(), e[3].getMinutes(), __MilitaryTime));
                    $("#bbit-cs-buddle-timeshow").html(r.join(""));
                    $("#bbit-cs-id").val(e[0]), $(".dialogdwm_event_content").find("#bbit-cs-title").html(e[1]), $(".dialogdwm_event_content").find("#bbit-cs-location").html(e[9]), $(".dialogdwm_event_content").find("#bbit-cs-description").html(e[11]), o.data("cdata", e), $(document).one("click", (function() {
                        try {
                            $("#bbit-cs-buddle").dialog("close")
                        } catch (t) {}
                    }))
                } else option.ViewCmdhandler ? option.ViewCmdhandler && $.isFunction(option.ViewCmdhandler) && option.ViewCmdhandler.call(this, e) : alert("ViewCmdhandler" + i18n.dcmvcal.i_undefined);
            else alert(i18n.dcmvcal.data_format_error);
            t.stopPropagation()
        }

        function moreshow(t) {
            var e = $(this),
                a = t.id.replace(option.thecontainer, "").split("_")[1],
                o = $(t),
                n = e.position(),
                i = o.position(),
                r = 1.5 * (e.width() + 2),
                d = i.top + 15,
                s = n.left,
                l = str_MdyyyyHHmm_todate($(this).attr("abbr") + " 00:00"),
                p = $("#cal-month-cc" + option.thecontainer),
                c = $("#cal-month-cc-content" + option.thecontainer + " table tbody");
            $("#cal-month-cc-title" + option.thecontainer).html(dateFormat.call(l, i18n.dcmvcal.dateformat.Md3) + " " + __WDAY[l.getDay()]), c.empty();
            for (var h = $("#gridEvent" + option.thecontainer).data("mvdata"), u = h[a], v = parseInt(this.axis), m = [], g = 0; g <= v; g++)
                for (var f = u[g] ? u[g].length : 0, y = 0; y < f; y++) {
                    var w = u[g][y];
                    w && w.colSpan + g - 1 >= v && (m.push("<tr><td class='st-c'>"), m.push(BuildMonthDayEvent(w, l, 1)), m.push("</td></tr>"))
                }
            c.html(m.join("")), c.find("div.rb-o").each((function(t) {
                $(this).click(dayshow), option.showtooltipdwm_mouseover && $(this).mouseover(dayshow)
            })), h = u = null;
            var b = p.height(),
                _ = document.documentElement.clientWidth,
                D = document.documentElement.clientHeight;
            s + r >= _ && (s = n.left - .5 * (e.width() + 2)), d + b >= D && (d = D - b - 2);
            var E = {
                left: s,
                top: d,
                width: r,
                visibility: "visible"
            };
            return p.css(E), $(document).one("click", closeCc), !1
        }

        function dayupdate(t, e, a) {
            if ("" != t[6] && "0" != t[6]) return alert("Information: Recurrent events cannot be moved this way. Edit its details to modify it."), populate(), !1;
            if ("" != option.quickUpdateUrl && 1 == t[8] && 1 != option.readonly && (option.userEdit || option.userOwner == t[12] && option.userEditOwner)) {
                if (option.isloading) return !1;
                option.isloading = !0;
                var o, n = t[0],
                    i = t[2],
                    r = t[3],
                    d = (new Date).getTimezoneOffset() / 60 * -1,
                    s = [{
                        name: "calendarId",
                        value: n
                    }, {
                        name: "CalendarStartTime",
                        value: dateFormat.call(e, "M/d/yyyy HH:mm")
                    }, {
                        name: "CalendarEndTime",
                        value: dateFormat.call(a, "M/d/yyyy HH:mm")
                    }, {
                        name: "timezone",
                        value: d
                    }];
                option.quickUpdateHandler && $.isFunction(option.quickUpdateHandler) ? option.quickUpdateHandler.call(this, s) : (option.onBeforeRequestData && option.onBeforeRequestData(4), $.post(option.quickUpdateUrl, s, (function(t) {
                    t && (1 == t.IsSuccess ? (option.isloading = !1, option.onAfterRequestData && option.onAfterRequestData(4)) : (option.onRequestDataError && option.onRequestDataError(4, t), option.isloading = !1, (o = rebyKey(n, !0))[2] = i, o[3] = r, Ind(o), render(), o = null, option.onAfterRequestData && option.onAfterRequestData(4)))
                }), "json"), (o = rebyKey(n, !0)) && (o[2] = e, o[3] = a), Ind(o), render())
            }
        }

        function closeOpenDlg() {
            $("#bbit-cal-buddle").remove(), $(".mv_dlg").remove(), $("#bbit-cs-buddle").remove(), $("#editeventdlg").remove()
        }

        function quickadd(t, e, a, o) {
            if ((option.quickAddHandler || "" != option.quickAddUrl) && !option.readonly && option.userAdd) {
                closeOpenDlg();
                var n = $.datepicker.formatDate("yy-mm-dd", t) + " " + t.getHours() + ":" + t.getMinutes();
                // The event editor opens in a new tab (see tzfdOpenInNewTab in Common.js).
                // option.dlgiframe is set by tzfdcalendar.js; it was never set before, so this
                // path used to load a broken address.
                if (option.dlgiframe) {
                    tzfdOpenInNewTab(option.dlgiframe + "&st=" + encodeURIComponent(n) + "&op=" + encodeURIComponent(option.thecontainer));
                }
            }
        }

        function strtodate(t) {
            var e = t.split(" "),
                a = e[0].split(i18n.dcmvcal.dateformat.separator),
                o = e[1].split(":"),
                n = a[i18n.dcmvcal.dateformat.year_index],
                i = 0 == a[i18n.dcmvcal.dateformat.month_index].indexOf("0") ? a[i18n.dcmvcal.dateformat.month_index].substr(1, 1) : a[i18n.dcmvcal.dateformat.month_index],
                r = 0 == a[i18n.dcmvcal.dateformat.day_index].indexOf("0") ? a[i18n.dcmvcal.dateformat.day_index].substr(1, 1) : a[i18n.dcmvcal.dateformat.day_index],
                d = 0 == o[0].indexOf("0") ? o[0].substr(1, 1) : o[0],
                s = 0 == o[1].indexOf("0") ? o[1].substr(1, 1) : o[1];
            return new Date(n, parseInt(i) - 1, r, d, s)
        }

        function datetostr(t) {
            return t.getFullYear() + "/" + (t.getMonth() + 1) + "/" + t.getDate()
        }

        function str_MdyyyyHHmm_todate(t) {
            var e = t.split(" "),
                a = e[0].split("/"),
                o = e[1].split(":"),
                n = a[2],
                i = 0 == a[0].indexOf("0") ? a[0].substr(1, 1) : a[0],
                r = 0 == a[1].indexOf("0") ? a[1].substr(1, 1) : a[1],
                d = 0 == o[0].indexOf("0") ? o[0].substr(1, 1) : o[0],
                s = 0 == o[1].indexOf("0") ? o[1].substr(1, 1) : o[1];
            return new Date(n, parseInt(i) - 1, r, d, s)
        }

        function rebyKey(t, e) {
            if (option.eventItems && option.eventItems.length > 0) {
                for (var a = option.eventItems.length, o = -1, n = 0; n < a; n++)
                    if (option.eventItems[n][0] == t) {
                        o = n;
                        break
                    } if (o >= 0) {
                    var i = option.eventItems[o];
                    return e && option.eventItems.splice(o, 1), i
                }
            }
            return null
        }

        function Ind(t, e) {
            var a = 0;
            if (e) a = 1;
            else if (option.eventItems && option.eventItems.length > 0) {
                var o = option.eventItems.length,
                    n = t[2],
                    i = n.getTime() - option.eventItems[0][2].getTime(),
                    r = option.eventItems[o - 1][2].getTime() - n.getTime();
                if (i < 0 || i - r < 0) {
                    for (var d = 0; d < o; d++)
                        if (option.eventItems[d][2] >= n) {
                            e = d;
                            break
                        }
                } else if (r < 0) e = o;
                else
                    for (d = o - 1; d >= 0; d--)
                        if (option.eventItems[d][2] < n) {
                            e = d + 1;
                            break
                        }
            } else e = 0;
            return option.eventItems && option.eventItems.length > 0 ? e == option.eventItems.length ? option.eventItems.push(t) : option.eventItems.splice(e, a, t) : option.eventItems = [t], e
        }

        function ResizeView(t) {
            document.documentElement.clientHeight;
            var e = option.view;
            if ("day" == e || "week" == e || "nDays" == e || "rowMonth" == e) {
                var a = $("#dvwkcontaienr" + t.thecontainer),
                    o = $("#dvtec" + t.thecontainer);
                if ((0 == a.length || 0 == o.length) && ("" == option.rowsList || option.dayWithTime && "day" == option.view)) return void alert(i18n.dcmvcal.view_no_ready);
                var n = a.height() + 2,
                    i = option.height - 8 - n;
                if (o.height(i), o.height("auto"), void 0 === option.scoll) {
                    var r = new Date,
                        d = r.getHours(),
                        s = gP(d, r.getMinutes()),
                        l = o.attr("clientHeight"),
                        p = s - .5 * l,
                        c = o.attr("scrollHeight");
                    p < 0 && (p = 0), p > c - l && (p = c - l - 10 * (23 - d)), o.attr("scrollTop", p)
                } else o.attr("scrollTop", option.scoll)
            }
        }

        function initevents(t) {
            if ("week" == t || "day" == t || "nDays" == t || "rowMonth" == t) {
                if ($("div.chip", gridcontainer).each((function(t) {
                        var e = $(this);
                        e.click(dayshow), option.showtooltipdwm_mouseover && e.mouseover(dayshow), e.hasClass("drag") ? (e.mousedown((function(t) {
                            dragStart.call(this, "dw3", t), t.stopPropagation()
                        })), e.find("div.resizer").mousedown((function(t) {
                            dragStart.call($(this).parent().parent(), "dw4", t), t.stopPropagation()
                        }))) : e.mousedown((function(t) {
                            t.stopPropagation()
                        }))
                    })), $("div.rb-o", gridcontainer).each((function(e) {
                        var a = $(this);
                        a.click(dayshow), option.showtooltipdwm_mouseover && a.mouseover(dayshow), !a.hasClass("drag") || "week" != t && "nDays" != t && "rowMonth" != t ? a.mousedown((function(t) {
                            t.stopPropagation()
                        })) : a.mousedown((function(t) {
                            dragStart.call(this, {
                                dw5: "dw5",
                                row: a.attr("row")
                            }, t), t.stopPropagation()
                        }))
                    })), 0 == option.readonly && option.userAdd && ($("td.tg-col", gridcontainer).each((function(t) {
                        $(this).mousedown((function(t) {
                            dragStart.call(this, "dw1", t), t.stopPropagation()
                        }))
                    })), $("#weekViewAllDaywk" + option.thecontainer).mousedown((function(t) {
                        dragStart.call(this, "dw2", t), t.stopPropagation()
                    })), !("" == option.rowsList || option.dayWithTime && "day" == option.view)))
                    for (var a = 0; a < option.rowsList.length; a++) $("#weekViewAllDaywk" + option.thecontainer + a).mousedown((function(t) {
                        dragStart.call(this, "dw2", t), t.stopPropagation()
                    }));
                "week" != t && "nDays" != t && "rowMonth" != t || $("#dvwkcontaienr" + option.thecontainer + " th.gcweekname").each((function(t) {
                    $(this).click(weekormonthtoday)
                }))
            } else(t = "month") && ($("div.rb-o", gridcontainer).each((function(t) {
                var e = $(this);
                e.click(dayshow), option.showtooltipdwm_mouseover && e.mouseover(dayshow), e.hasClass("drag") ? e.mousedown((function(t) {
                    dragStart.call(this, "m2", t), t.stopPropagation()
                })) : e.mousedown((function(t) {
                    t.stopPropagation()
                }))
            })), $("td.st-more", gridcontainer).each((function(t) {
                $(this).click((function(t) {
                    moreshow.call(this, $(this).parent().parent().parent().parent()[0]), t.stopPropagation()
                })).mousedown((function() {
                    e.stopPropagation()
                }))
            })), 0 == option.readonly && option.userAdd && $("#mvEventContainer" + option.thecontainer).mousedown((function(t) {
                dragStart.call(this, "m1", t), t.stopPropagation()
            })))
        }

        function realsedragevent() {
            _dragevent && (_dragevent(), _dragevent = null)
        }

        function dragStart(t, e) {
            var a = $(this);
            e.srcElement || e.target;
            realsedragevent();
            var o = "";
            if ("dw5" == t.dw5) {
                o = t.row;
                t = "dw5"
            }
            switch (t) {
                case "dw1":
                    _dragdata = {
                        type: 1,
                        target: a,
                        sx: e.pageX,
                        sy: e.pageY
                    };
                    break;
                case "dw2":
                    for (var n = a.width(), i = a.height(), r = (y = a.offset()).left, d = y.top, s = n % (b = "day" == option.view ? 1 : "week" == option.view ? __VIEWWEEKDAYSTOTAL : option.nOfDays), l = n / b, p = [], c = [], h = 0; h < b; h++) p.push({
                        s: parseInt(h * l + r),
                        e: parseInt((h + 1) * l + r)
                    });
                    c.push({
                        s: d,
                        e: d + i
                    }), _dragdata = {
                        type: 2,
                        target: a,
                        sx: e.pageX,
                        sy: e.pageY,
                        pw: parseInt(l),
                        xa: p,
                        ya: c,
                        h: i
                    }, n = r = b = s = l = p = null;
                    break;
                case "dw3":
                    var u = a.parent().attr("id").replace("tgCol" + option.thecontainer, ""),
                        v = a.parent(),
                        m = v.offset(),
                        g = (n = v.width() + 10, i = a.height(), getdata(a));
                    _dragdata = {
                        type: 4,
                        target: a,
                        sx: e.pageX,
                        sy: e.pageY,
                        pXMin: m.left,
                        pXMax: m.left + n,
                        pw: n,
                        h: i,
                        cdi: parseInt(u),
                        fdi: parseInt(u),
                        data: g
                    };
                    break;
                case "dw4":
                    i = a.height(), g = getdata(a);
                    _dragdata = {
                        type: 5,
                        target: a,
                        sx: e.pageX,
                        sy: e.pageY,
                        h: i,
                        data: g
                    };
                    break;
                case "dw5":
                    var f = $("#weekViewAllDaywk" + option.thecontainer + o),
                        y = (n = f.width(), i = f.height(), f.offset()),
                        w = a.offset();
                    r = y.left, d = y.top;
                    if ("week" == option.view) var b = 7;
                    else b = option.nOfDays;
                    s = n % b, l = parseInt(n / b);
                    s > b / 2 + 1 && l++;
                    p = [], c = [];
                    var _ = 0;
                    for (h = 0; h < b; h++) p.push({
                        s: h * l + r,
                        e: (h + 1) * l + r
                    }), w.left >= p[h].s && w.left < p[h].e && (_ = h);
                    var D = {
                        x: _,
                        y: 0,
                        di: _
                    };
                    c.push({
                        s: d,
                        e: d + i
                    });
                    g = getdata(a);
                    var E = DateDiff("d", g[2], g[3]) + 1;
                    _dragdata = {
                        type: 6,
                        target: a,
                        sx: e.pageX,
                        sy: e.pageY,
                        data: g,
                        xa: p,
                        ya: c,
                        fdi: D,
                        h: i,
                        dp: E,
                        pw: l
                    };
                    break;
                case "m1":
                    n = a.width(), r = (y = a.offset()).left, d = y.top, b = __VIEWWEEKDAYSTOTAL;
                    var M = a.children().length;
                    s = n % b, l = parseInt(n / b);
                    s > b / 2 + 1 && l++;
                    for (i = $("#mvrow" + option.thecontainer + "_0").height(), p = [], c = [], h = 0; h < b; h++) p.push({
                        s: h * l + r,
                        e: (h + 1) * l + r
                    });
                    i = 0;
                    var k = d,
                        x = 0;
                    for (h = 0; h < M; h++) x = k + (i = $("#mvrow" + option.thecontainer + "_" + h).height()), c.push({
                        s: k,
                        e: x
                    }), k = x;
                    _dragdata = {
                        type: 3,
                        target: a,
                        sx: e.pageX,
                        sy: e.pageY,
                        pw: l,
                        xa: p,
                        ya: c,
                        h: i
                    };
                    break;
                case "m2":
                    var A = $("#mvrow" + option.thecontainer + "_0"),
                        W = $("#mvrow" + option.thecontainer + "_1"),
                        S = (n = A.width(), y = A.offset(), W.offset());
                    w = a.offset(), i = S.top - y.top, r = y.left, d = y.top, b = 7, M = A.parent().children().length, s = n % b, l = parseInt(n / b);
                    s > b / 2 + 1 && l++;
                    p = [], c = [];
                    var O = 0,
                        I = 0;
                    for (h = 0; h < b; h++) p.push({
                        s: h * l + r,
                        e: (h + 1) * l + r
                    }), w.left >= p[h].s && w.left < p[h].e && (O = h);
                    for (h = 0; h < M; h++) c.push({
                        s: h * i + d,
                        e: (h + 1) * i + d
                    }), w.top >= c[h].s && w.top < c[h].e && (I = h);
                    D = {
                        x: O,
                        y: I,
                        di: 7 * I + O
                    }, g = getdata(a), E = DateDiff("d", g[2], g[3]) + 1;
                    _dragdata = {
                        type: 7,
                        target: a,
                        sx: e.pageX,
                        sy: e.pageY,
                        data: g,
                        xa: p,
                        ya: c,
                        fdi: D,
                        h: i,
                        dp: E,
                        pw: l
                    }
            }
            $("body").noSelect()
        }

        function dragMove(t) {
            if (_dragdata) {
                var e = _dragdata;
                switch (e.type) {
                    case 1:
                        var a = e.sy;
                        if ((l = (y = t.pageY) - a) > option.cellheight / 4 || l < option.cellheight / 4 * -1 || e.tzfdwrap) {
                            0 == l && (l = option.cellheight / 2);
                            var o = l % (option.cellheight / 2);
                            0 != o && (l = o > 0 ? l + option.cellheight / 2 - o : l - option.cellheight / 2 - o, y = e.sy + l, l < 0 && (a += option.cellheight / 2)), e.tp || (e.tp = $(e.target).offset().top);
                            var n = gP((m = gH(a, y, e.tp)).sh, m.sm);
                            if (e.tzfdwrap) e.cgh.sh == m.sh && e.cgh.eh == m.eh && e.cgh.sm == m.sm && e.cgh.em == m.em || (g = buildtempdayevent(m.sh, m.sm, m.eh, m.em, m.h), e.tzfdwrap.css("top", n + "px").html(g));
                            else {
                                g = buildtempdayevent(m.sh, m.sm, m.eh, m.em, m.h);
                                var i = $("<div class='ca-evpi drag-chip-wrapper' style='top:" + n + "px'/>").html(g);
                                $(e.target).find("div.tg-col-overlaywrapper").append(i), e.tzfdwrap = i
                            }
                            e.cgh = m
                        }
                        break;
                    case 2:
                        var r = e.sx;
                        if ((_ = (s = t.pageX) - r) > 5 || _ < -5 || e.lasso) {
                            e.lasso || (e.lasso = $("<div style='display: block' class='drag-lasso-container'/>"), $(document.body).append(e.lasso)), e.sdi || (e.sdi = getdi(e.xa, e.ya, r, e.sy));
                            var d = getdi(e.xa, e.ya, s, t.pageY);
                            e.fdi && e.fdi.di == d.di || addlasso(e.lasso, e.sdi, d, e.xa, e.ya, e.h), e.fdi = d
                        }
                        break;
                    case 3:
                        r = e.sx;
                        var s = t.pageX,
                            l = (a = e.sy, (y = t.pageY) - a);
                        if ((_ = s - r) > 5 || _ < -5 || l < -5 || l > 5 || e.lasso) {
                            e.lasso || (e.lasso = $("<div style='display: block' class='drag-lasso-container'/>"), $(document.body).append(e.lasso)), e.sdi || (e.sdi = getdi(e.xa, e.ya, r, a));
                            d = getdi(e.xa, e.ya, s, y);
                            e.fdi && e.fdi.di == d.di || addlasso(e.lasso, e.sdi, d, e.xa, e.ya, e.h), e.fdi = d
                        }
                        break;
                    case 4:
                        if (null != (v = e.data) && 1 == v[8]) {
                            r = e.sx, s = t.pageX, a = e.sy, l = (y = t.pageY) - a;
                            if ((_ = s - r) > 5 || _ < -5 || l > 5 || l < -5 || e.tzfdwrap)
                                if (e.tzfdwrap) {
                                    var p = 0;
                                    if (s < e.pXMin ? p = -1 : s > e.pXMax && (p = 1), 0 != p) {
                                        e.cdi = e.cdi + p;
                                        var c = $("#tgOver" + option.thecontainer + e.cdi);
                                        1 == c.length ? (e.pXMin = e.pXMin + e.pw * p, e.pXMax = e.pXMax + e.pw * p, c.append(e.tzfdwrap)) : e.cdi = e.cdi - p
                                    }
                                    var h = (n = e.top + l) % (option.cellheight / 2);
                                    0 != h && (n -= h), e.ny != n && (g = buildtempdayevent((m = gW(n, n + e.h)).sh, m.sm, m.eh, m.em, m.h, v[1], !1, !1, v[7]), e.tzfdwrap.css("top", n + "px").html(g)), e.ny = n
                                } else {
                                    m = {
                                        sh: v[2].getHours(),
                                        sm: v[2].getMinutes(),
                                        eh: v[3].getHours(),
                                        em: v[3].getMinutes(),
                                        h: e.h
                                    }, e.target.hide(), n = gP(m.sh, m.sm), e.top = n, g = buildtempdayevent(m.sh, m.sm, m.eh, m.em, m.h, v[1], !1, !1, v[7]);
                                    i = $("<div class='ca-evpi drag-chip-wrapper' style='top:" + n + "px'/>").html(g);
                                    var u = e.target.parent().attr("id").replace("tgCol" + option.thecontainer, "#tgOver" + option.thecontainer);
                                    $(u).append(i), e.tzfdwrap = i, e.ny = n
                                }
                        }
                        break;
                    case 5:
                        var v;
                        if (null != (v = e.data) && 1 == v[8]) {
                            var m, g;
                            a = e.sy;
                            if (0 != (l = (y = t.pageY) - a) || e.tzfdwrap)
                                if (e.tzfdwrap) {
                                    nh = e.h + l;
                                    var f = nh % (option.cellheight / 2);
                                    if (nh = f > 1 ? nh - f + option.cellheight / 2 : nh - f, e.nh != nh) {
                                        gP(v[2].getHours(), v[2].getMinutes()), nh;
                                        g = buildtempdayevent((m = gW(e.top, e.top + nh)).sh, m.sm, m.eh, m.em, m.h, v[1], "100%", !0, v[7]), e.tzfdwrap.html(g)
                                    }
                                    e.nh = nh
                                } else {
                                    m = {
                                        sh: v[2].getHours(),
                                        sm: v[2].getMinutes(),
                                        eh: v[3].getHours(),
                                        em: v[3].getMinutes(),
                                        h: e.h
                                    }, e.target.hide(), n = gP(m.sh, m.sm), e.top = n, g = buildtempdayevent(m.sh, m.sm, m.eh, m.em, m.h, v[1], "100%", !0, v[7]);
                                    i = $("<div class='ca-evpi drag-chip-wrapper' style='top:" + n + "px'/>").html(g), u = e.target.parent().attr("id").replace("tgCol" + option.thecontainer, "#tgOver" + option.thecontainer);
                                    $(u).append(i), e.tzfdwrap = i
                                }
                        }
                        break;
                    case 6:
                        r = e.sx, s = t.pageX;
                        var y = t.pageY;
                        if ((_ = s - r) > 5 || _ < -5 || e.lasso) {
                            if (!e.lasso) {
                                var w = e.dp > 1 ? 1.5 * (e.pw - 4) : e.pw - 4,
                                    b = e.target.clone();
                                e.dp > 1 && b.find("div.rb-i>span").prepend("(" + e.dp + " " + i18n.dcmvcal.day_plural + ")&nbsp;");
                                i = $("<div class='drag-event st-contents' style='width:" + w + "px'/>").append(b).appendTo(document.body);
                                e.tzfdwrap = i, e.lasso = $("<div style='display: block' class='drag-lasso-container'/>"), $(document.body).append(e.lasso), b = i = null
                            }
                            fixcppostion(e.tzfdwrap, t, e.xa, e.ya);
                            d = getdi(e.xa, e.ya, s, t.pageY);
                            e.cdi && e.cdi.di == d.di || addlasso(e.lasso, d, {
                                x: d.x,
                                y: d.y,
                                di: d.di + e.dp - 1
                            }, e.xa, e.ya, e.h), e.cdi = d
                        }
                        break;
                    case 7:
                        var _;
                        r = e.sx, a = e.sy, s = t.pageX, l = (y = t.pageY) - a;
                        if ((_ = s - r) > 5 || _ < -5 || l > 5 || l < -5 || e.lasso) {
                            if (!e.lasso) {
                                w = e.dp > 1 ? 1.5 * (e.pw - 4) : e.pw - 4, b = e.target.clone();
                                e.dp > 1 && b.find("div.rb-i>span").prepend("(" + e.dp + " " + i18n.dcmvcal.day_plural + ")&nbsp;");
                                i = $("<div class='drag-event st-contents' style='width:" + w + "px'/>").append(b).appendTo(document.body);
                                e.tzfdwrap = i, e.lasso = $("<div style='display: block' class='drag-lasso-container'/>"), $(document.body).append(e.lasso), b = i = null
                            }
                            fixcppostion(e.tzfdwrap, t, e.xa, e.ya);
                            d = getdi(e.xa, e.ya, s, t.pageY);
                            e.cdi && e.cdi.di == d.di || addlasso(e.lasso, d, {
                                x: d.x,
                                y: d.y,
                                di: d.di + e.dp - 1
                            }, e.xa, e.ya, e.h), e.cdi = d
                        }
                }
            }
            t.stopPropagation()
        }

        function dragEnd(t) {
            if (_dragdata) {
                var e = _dragdata;
                switch (e.type) {
                    case 1:
                        var a = (new Date).getTime();
                        if (tp = e.target.offset().top, !e.tzfdwrap) {
                            var o = gP((g = gH(e.sy, e.sy + option.cellheight, tp)).sh, g.sm),
                                n = buildtempdayevent(g.sh, g.sm, g.eh, g.em, g.h);
                            e.tzfdwrap = $("<div class='ca-evpi drag-chip-wrapper' style='top:" + o + "px'/>").html(n), $(e.target).find("div.tg-col-overlaywrapper").append(e.tzfdwrap), e.cgh = g
                        }
                        var i = e.tzfdwrap.offset();
                        i.left = i.left + 30, e.tzfdwrap.attr("id", a);
                        var r = str_MdyyyyHHmm_todate(e.target.attr("abbr") + " " + e.cgh.sh + ":" + e.cgh.sm),
                            d = str_MdyyyyHHmm_todate(e.target.attr("abbr") + " " + e.cgh.eh + ":" + e.cgh.em);
                        _dragevent = function() {
                            $("#" + a).remove(), $("#bbit-cal-buddle").dialog("close")
                        };
                        try {
                            i.col = e.tzfdwrap.parent().parent().attr("col")
                        } catch (t) {}
                        quickadd(r, d, !1, i);
                        break;
                    case 2:
                    case 3:
                        var s = t.srcElement || t.target,
                            l = (new Date).getTime();
                        if (!e.lasso) {
                            if ($(s).hasClass("monthdayshow")) {
                                weekormonthtoday.call($(s).parent()[0], t);
                                break
                            }
                            e.fdi = e.sdi = getdi(e.xa, e.ya, e.sx, e.sy), e.lasso = $("<div style='display: block' class='drag-lasso-container'/>"), $(document.body).append(e.lasso), addlasso(e.lasso, e.sdi, e.fdi, e.xa, e.ya, e.ya[e.fdi.y].e - e.ya[e.fdi.y].s)
                        }
                        e.lasso.attr("id", l);
                        for (var p = Math.min(e.fdi.di, e.sdi.di), c = Math.max(e.fdi.di, e.sdi.di), h = option.vstart, u = 0, v = 0; v <= p;) {
                            var m = DateAdd("d", u, h);
                            v += __VIEWWEEKDAYS[m.getDay()], u++
                        }
                        c = --u;
                        r = DateAdd("d", p = u, h), d = DateAdd("d", c, h);
                        _dragevent = function() {
                            $("#" + l).remove()
                        }, $(s).hasClass("st-more") || quickadd(r, d, !0, {
                            left: t.pageX,
                            top: t.pageY
                        });
                        break;
                    case 4:
                        if (e.tzfdwrap) {
                            r = DateAdd("d", e.cdi, option.vstart), d = DateAdd("d", e.cdi, option.vstart);
                            var g = gW(e.ny, e.ny + e.h);
                            r.setHours(g.sh, g.sm), d.setHours(g.eh, g.em), r.getTime() == e.data[2].getTime() && d.getTime() == e.data[3].getTime() ? (e.tzfdwrap.remove(), e.target.show()) : dayupdate(e.data, r, d)
                        }
                        break;
                    case 5:
                        if (e.tzfdwrap) {
                            r = new Date(e.data[2].toString()), d = new Date(e.data[3].toString()), g = gW(e.top, e.top + nh);
                            r.setHours(g.sh, g.sm), d.setHours(g.eh, g.em), r.getTime() == e.data[2].getTime() && d.getTime() == e.data[3].getTime() ? (e.tzfdwrap.remove(), e.target.show()) : dayupdate(e.data, r, d)
                        }
                        break;
                    case 6:
                    case 7:
                        if (e.lasso) {
                            e.tzfdwrap.remove(), e.lasso.remove();
                            r = new Date(e.data[2].toString()), d = new Date(e.data[3].toString());
                            var f = DateAdd("d", e.cdi.di, option.vstart),
                                y = DateDiff("d", r, f);
                            r = DateAdd("d", y, r), d = DateAdd("d", y, d), r.getTime() == e.data[2].getTime() && d.getTime() == e.data[3].getTime() || dayupdate(e.data, r, d)
                        }
                }
                e = _dragdata = null, $("body").noSelect(!1), t.stopPropagation()
            }
        }

        function getdi(t, e, a, o) {
            var n = 0,
                i = 0,
                r = 0,
                d = 0;
            if (t && 0 != t.length)
                if (a >= t[(r = t.length) - 1].e) i = r - 1;
                else
                    for (var s = 0; s < r; s++)
                        if (a > t[s].s && a <= t[s].e) {
                            i = s;
                            break
                        } if (e && 0 != e.length)
                if (o >= e[(d = e.length) - 1].e) n = d - 1;
                else
                    for (var l = 0; l < d; l++)
                        if (o > e[l].s && o <= e[l].e) {
                            n = l;
                            break
                        } return {
                x: i,
                y: n,
                di: n * r + i
            }
        }

        function addlasso(t, e, a, o, n, i) {
            var r = e.di > a.di ? e.di - a.di : a.di - e.di;
            r++;
            var d = e.di > a.di ? a : e,
                s = (e.di, a.di, o.length > 0 ? o.length : 1),
                l = n.length > 0 ? n.length : 1,
                p = [],
                c = o[0].e - o[0].s + 1,
                h = d.x,
                u = d.y;
            for (Math.min(document.documentElement.clientWidth, o[s - 1].e); u < l && r > 0;) {
                var v = o[h].s,
                    m = h + r > s ? s - h : r,
                    g = c * m;
                p.push(Tp(__LASSOTEMP, {
                    left: v + 1,
                    top: n[u].s + 4,
                    height: i,
                    width: g
                })), h = 0, r -= m, u++
            }
            t.html(p.join(""))
        }

        function fixcppostion(t, e, a, o) {
            var n = e.pageX - 6,
                i = e.pageY - 4,
                r = t.width(),
                d = option.cellheight / 2,
                s = a[0].s + 6,
                l = o[0].s + 4,
                p = a[a.length - 1].e - r - 2,
                c = o[o.length - 1].e - d - 2;
            n > p && (n = p), n <= s && (n = s + 1), i <= l && (i = l + 1), i > c && (i = c), t.css({
                left: n,
                top: i
            })
        }
        $(window).resize((function() {
            adaptWH(), option.newWidthGroupCalculate && (option.newWidthGroup = 0, render())
        })), $(document).mousemove(dragMove).mouseup(dragEnd);
        var c = {
            sv: function(t) {
                t != option.view && (clearcontainer(), option.view = t, "list" == option.view && (option.eventItems = [], option.lastdate = "", option.currentlist = {
                    dend: "",
                    idend: 0
                }, option.cachepages = new Array), render(), dochange())
            },
            rf2: function() {
                option.newWidthGroup = 0, render()
            },
            rf: function() {
                populate()
            },
            gt: function(t) {
                t || (t = new Date), option.showday = t, render(), dochange()
            },
            pv: function() {
                switch (option.view) {
                    case "day":
                        option.showday = DateAdd("d", -1, option.showday);
                        break;
                    case "week":
                        option.showday = DateAdd("w", -1, option.showday);
                        break;
                    case "nDays":
                    case "rowMonth":
                        option.showday = DateAdd("d", -1 * option.nOfDays, option.showday);
                        break;
                    case "list":
                        option.page--;
                        break;
                    case "month":
                    case "nMonth":
                        option.showday = DateAdd("m", -1, option.showday)
                }
                render(), "list" != option.view && dochange()
            },
            nt: function() {
                switch (option.view) {
                    case "day":
                        option.showday = DateAdd("d", 1, option.showday);
                        break;
                    case "week":
                        option.showday = DateAdd("w", 1, option.showday);
                        break;
                    case "nDays":
                    case "rowMonth":
                        option.showday = DateAdd("d", option.nOfDays, option.showday);
                        break;
                    case "list":
                        option.lastdate = option.currentlist.dend, option.page++;
                        break;
                    case "month":
                    case "nMonth":
                        var t = option.showday.getDate();
                        option.showday = DateAdd("m", 1, option.showday);
                        var e = option.showday.getDate();
                        t != e && (option.showday = DateAdd("d", 0 - e, option.showday))
                }("list" != option.view || "list" == option.view && option.cachepages.length > option.page) && render(), ("list" != option.view || "list" == option.view && option.cachepages.length <= option.page) && dochange()
            },
            go: function() {
                return option
            },
            so: function(t) {
                option = $.extend(option, t)
            }
        };
        return this[0].bcal = c, this
    }, $.fn.swtichView = function(t) {
        return $(".mv_dlg").remove(), this.each((function() {
            this.bcal && this.bcal.sv(t)
        }))
    }, $.fn.reload = function() {
        return this.each((function() {
            this.bcal && this.bcal.rf()
        }))
    }, $.fn.reload2 = function() {
        return this.each((function() {
            this.bcal && this.bcal.rf2()
        }))
    }, $.fn.gotoDate = function(t) {
        return this.each((function() {
            this.bcal && this.bcal.gt(t)
        }))
    }, $.fn.previousRange = function() {
        return this.each((function() {
            this.bcal && this.bcal.pv()
        }))
    }, $.fn.nextRange = function() {
        return this.each((function() {
            this.bcal && this.bcal.nt()
        }))
    }, $.fn.BcalGetOp = function() {
        return this[0].bcal ? this[0].bcal.go() : null
    }, $.fn.BcalSetOp = function(t) {
        if (this[0].bcal) return this[0].bcal.so(t)
    }
})(jQuery);
